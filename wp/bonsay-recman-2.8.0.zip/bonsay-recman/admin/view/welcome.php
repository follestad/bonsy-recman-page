<?php /** @noinspection PhpUnhandledExceptionInspection */

if (!defined('ABSPATH')) exit; ?>

<div id="bonsy-welcome">
    <i class='close' id='closeWelcome'><span class='dashicons dashicons-no-alt'></span> </i>
    <figure>
        <div class='image'
             style="background-image: url('<?php echo BONSY_RECMAN_PLUGIN_DIR_URL . 'admin/images/rocket.svg'; ?>')"></div>
    </figure>
    <div class="text">
        <h2>Welcome</h2>
        <p>
            Bonsy Recman WP Plugin makes it easy to show job posts from RecMan on your WordPress site.
            The plugin will automatically cache job posts locally for better performance and fewer API requests.
        </p>
        <p class="welcome-buttons">
            <a href="https://recman.bonsy.no" target="_blank" class="bonsy-button ghost">Learn more</a>
            <a href="https://bonsy.gitbook.io/bonsay-recman-wp/" target="_blank" class="bonsy-button">View
                Documentation</a>
        </p>
    </div>
    <div class="waveDivider">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none">
            <path fill="#fff"
                  d="M421.9,6.5c22.6-2.5,51.5,0.4,75.5,5.3c23.6,4.9,70.9,23.5,100.5,35.7c75.8,32.2,133.7,44.5,192.6,49.7  c23.6,2.1,48.7,3.5,103.4-2.5c54.7-6,106.2-25.6,106.2-25.6V0H0v30.3c0,0,72,32.6,158.4,30.5c39.2-0.7,92.8-6.7,134-22.4  c21.2-8.1,52.2-18.2,79.7-24.2C399.3,7.9,411.6,7.5,421.9,6.5z"></path>
        </svg>
    </div>
</div>


<script type="text/javascript">
    document.getElementById('closeWelcome').addEventListener("click", () => {
        document.getElementById('bonsy-welcome').remove();
    });
</script>
