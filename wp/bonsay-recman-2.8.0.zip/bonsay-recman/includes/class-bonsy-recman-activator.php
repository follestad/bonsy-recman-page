<?php
/**
 * Plugin activation class
 *
 * @package RecMan\Includes
 */

defined('WPINC') || exit;


class Bonsy_Recman_Activator {

    public static function activate(): void {
        if (!get_option('bonsy_recman_cron_secret_key')) {
            update_option('bonsy_recman_cron_secret_key', wp_generate_password(32, false));
        }
        flush_rewrite_rules();
    }


}
