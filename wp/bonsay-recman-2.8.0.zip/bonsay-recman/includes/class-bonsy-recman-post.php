<?php
/**
 * The file that defines the plugin gutenberg
 *
 * @package RecMan\Includes
 */

defined('WPINC') || exit;



class Bonsy_Recman_Post {

    private const JOB_POST_TYPE = 'job_post';
    private const JOB_API_ID_META_KEY = 'job_post_id';
    private const LAST_UPDATED_META_KEY = 'last_updated';

    private Bonsy_Recman_Jobs $recman_api;



    public function __construct(Bonsy_Recman_Jobs $recman_api) {

        $this->recman_api = $recman_api;

        // Disable AFC as it will automatically disable WP custom fields.
        add_filter('acf/settings/remove_wp_meta_box', static function ($state) {
            if (($screen = get_current_screen()) && $screen->post_type === self::JOB_POST_TYPE) {
                return false;
            }
            return $state;
        });

        add_action('init', [$this, 'job_post_custom_post_type_init']);
        add_action('admin_notices', [$this, 'notice']);

        add_filter('query_vars', [$this, 'add_query_vars']);
        add_action('init', [$this, 'add_cron_rewrite_rule']);
        add_action('template_redirect', [$this, 'handle_cron_request']);

    }



    public function add_query_vars($vars) {
        $vars[] = 'bonsy_recman_cron_key';
        return $vars;
    }



    public function add_cron_rewrite_rule(): void {
        add_rewrite_rule('^bonsy-recman-cron/([^/]+)/?$', 'index.php?bonsy_recman_cron_key=$matches[1]', 'top');
    }



    public function notice(): void {
        $screen = get_current_screen();
        if ($screen && $screen->post_type === self::JOB_POST_TYPE) {
            echo '<div class="notice notice-warning is-dismissible">
            <p><strong>Warning:</strong> Changes made to job posts will be overwritten by the RecMan WordPress plugin. To change content, edit the job post inside your <a href="https://app.recman.no/" target="_blank">RecMan account</a>.</p>
        </div>';
        }
    }



    /**
     * Register a custom post-type called "book".
     *
     * @see get_post_type_labels() for label keys.
     */
    public function job_post_custom_post_type_init(): void {
        $labels = [
            'name'                  => _x('Job Posts', 'Post type general name', 'bonsy-recman'),
            'singular_name'         => _x('Job Post', 'Post type singular name', 'bonsy-recman'),
            'menu_name'             => _x('Job Posts', 'Admin Menu text', 'bonsy-recman'),
            'name_admin_bar'        => _x('Job Post', 'Add New on Toolbar', 'bonsy-recman'),
            'add_new'               => __('Add New', 'bonsy-recman'),
            'add_new_item'          => __('Add New Job Post', 'bonsy-recman'),
            'new_item'              => __('New Job Post', 'bonsy-recman'),
            'edit_item'             => __('Edit Job Post', 'bonsy-recman'),
            'view_item'             => __('View Job Post', 'bonsy-recman'),
            'all_items'             => __('All Job Posts', 'bonsy-recman'),
            'search_items'          => __('Search Job Posts', 'bonsy-recman'),
            'parent_item_colon'     => __('Parent Job Post:', 'bonsy-recman'),
            'not_found'             => __('No job posts found.', 'bonsy-recman'),
            'not_found_in_trash'    => __('No job posts found in Trash.', 'bonsy-recman'),
            'featured_image'        => _x('Job Post Cover Image', 'Overrides the “Featured Image” phrase for this post type. Added in 4.3', 'bonsy-recman'),
            'set_featured_image'    => _x('Set cover image', 'Overrides the “Set featured image” phrase for this post type. Added in 4.3', 'bonsy-recman'),
            'remove_featured_image' => _x('Remove cover image', 'Overrides the “Remove featured image” phrase for this post type. Added in 4.3', 'bonsy-recman'),
            'use_featured_image'    => _x('Use as cover image', 'Overrides the “Use as featured image” phrase for this post type. Added in 4.3', 'bonsy-recman'),
            'archives'              => _x('Job Post archives', 'The post type archive label used in nav menus. Default “Post Archives”. Added in 4.4', 'bonsy-recman'),
            'insert_into_item'      => _x('Insert in to job post', 'Overrides the “Insert into post”/”Insert into page” phrase (used when inserting media into a post). Added in 4.4', 'bonsy-recman'),
            'uploaded_to_this_item' => _x('Uploaded to this job post', 'Overrides the “Uploaded to this post”/”Uploaded to this page” phrase (used when viewing media attached to a post). Added in 4.4', 'bonsy-recman'),
            'filter_items_list'     => _x('Filter job posts list', 'Screen reader text for the filter links heading on the post type listing screen. Default “Filter posts list”/”Filter pages list”. Added in 4.4', 'bonsy-recman'),
            'items_list_navigation' => _x('Job post list navigation', 'Screen reader text for the pagination heading on the post type listing screen. Default “Posts list navigation”/”Pages list navigation”. Added in 4.4', 'bonsy-recman'),
            'items_list'            => _x('Job post list', 'Screen reader text for the items list heading on the post type listing screen. Default “Posts list”/”Pages list”. Added in 4.4', 'bonsy-recman'),
        ];

        $args = [
            'labels'             => $labels,
            'public'             => true, // Set to true to show the post-type in the admin dashboard
            'publicly_queryable' => true,
            'show_in_rest'       => true, // Shows in the gutenberg editor
            'show_ui'            => true, // Set to true to generate a UI for managing this post-type
            'show_in_menu'       => true, // Set to true to show in the admin menu
            'query_var'          => true,
            'rewrite'            => ['slug' => 'jobs'],
            'capability_type'    => 'post',
            'capabilities'       => [
                'edit_posts'   => 'manage_options', // Only users who can manage options can edit posts
                'create_posts' => 'do_not_allow',   // Disables adding new posts
            ],
            'map_meta_cap'       => true, // Required to use 'capabilities'
            'menu_icon'          => 'dashicons-groups',
            'has_archive'        => true,
            'hierarchical'       => false,
            'menu_position'      => null,
            'supports'           => ['title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments', 'custom-fields'],
        ];
        register_post_type(self::JOB_POST_TYPE, $args);
    }



    public function handle_cron_request(): void {
        $cron_key = get_query_var('bonsy_recman_cron_key');
        $expected_key = get_option('bonsy_recman_cron_secret_key'); // Get the stored secret key

        if ($cron_key && $cron_key === $expected_key) {
            // Disable caching for this request to ensure it always runs
            if (!defined('DONOTCACHEPAGE')) {
                define('DONOTCACHEPAGE', true);
            }
            if (!defined('DONOTCACHEDB')) {
                define('DONOTCACHEDB', true);
            }
            if (!defined('DONOTCACHEOBJECT')) {
                define('DONOTCACHEOBJECT', true);
            }

            // Include the necessary files for media handling if they haven't been loaded
            // This is crucial if your cron job runs in a very minimal WordPress environment
            // and `wp-admin/includes/image.php` etc. are not automatically available.
            // However, if the `template_redirect` hook is used,
            // core WP functions are generally available.
            require_once(ABSPATH . 'wp-admin/includes/image.php');
            require_once(ABSPATH . 'wp-admin/includes/file.php');
            require_once(ABSPATH . 'wp-admin/includes/media.php');

            try {
                $logs = $this->createCustomPostTypeContent();
                wp_send_json_success([
                    'message' => 'Cron job executed successfully.',
                    'details' => $logs,
                ]);
            } catch (Throwable $e) {
                wp_send_json_error([
                    'message' => 'Job failed: ' . $e->getMessage(),
                    'details' => [],
                ]);
            }

            exit(); // Terminate script after execution
        }
    }



    private function createCustomPostTypeContent(): array {

        $logs = [];

        // --- STEP 1: Get all currently published job_post IDs from WordPress ---
        // This associative array will store: [api_job_id => wp_post_id]
        $current_published_wp_job_posts = $this->get_published_job_posts_with_api_ids();
        $processed_wp_post_ids_this_run = []; // Collects WP IDs that were updated/created from the current API feed

        // Reset job post loop - important if the job post loop has been used earlier in the page
        $this->recman_api->reset_loop();

        // --- Handle case where no jobs are returned from RecMan API ---
        if (!$this->recman_api->have_jobs(0, 0)) {
            error_log('Bonsy RecMan Cron: No job posts found from RecMan API. Marking all existing WP job posts as private.');
            $logs[] = 'No job posts found from RecMan API. Marking all existing WP job posts as private.';
            foreach ($current_published_wp_job_posts as $api_id => $wp_id) {
                $this->mark_job_post_as_private($wp_id);
                $logs[] = "Marked job post WP ID: $wp_id (API ID: $api_id) as private.";
            }
            return $logs; // No API jobs, so no further processing needed
        }

        $custom_fields = [
            'name', 'title', 'startDate', 'endDate', 'numberOfPositions', 'accession', 'salary', 'sector', 'type', 'position', 'positionType', 'deadline', 'logo', 'created', 'updated', 'companyName', 'workplace', 'facebook', 'linkedIn', 'twitter', 'departmentId', 'corporationId', 'videoUrl', 'address1', 'address2', 'postalCode', 'city', 'country', 'isExpired', 'url', 'apply', 'some_title', 'some_description', 'some_image', 'some_image_full', 'companyDescription', 'website', 'branchCategory', 'branch', 'secondaryBranchCategory', 'secondaryBranch', 'location_city', 'location_country', 'location_region', 'department', 'corporation', 'similarJobs', 'skills', 'images', 'contacts',
        ];

        while ($this->recman_api->have_jobs(0, 0)) {

            $this->recman_api->the_job();

            $api_job_id = get_jobpost('jobPostId');

            if (!$api_job_id) {
                error_log('Bonsy_Recman_Post: API job post missing jobPostId. Skipping this job.');
                $logs[] = 'Warning: A job post from RecMan API was missing jobPostId. Skipping.';
                continue; // Skip this job if its ID is missing
            }

            // Assuming $post_id is the ID of your post
            $updated_timestamp = strtotime(get_jobpost('updated'));
            // Check if a post exists by API ID, could be published or private
            $wp_post_id = $this->check_if_post_exists_by_api_id($api_job_id);

            // Prepare post-data
            $post_data = [
                'post_title'   => wp_strip_all_tags(get_jobpost('name')),          // Set the title of your job post
                'post_content' => get_jobpost('body'),                             // Set the content of your job post
                'post_status'  => 'publish',                                       // Set the status of your job post,
                'post_type'    => self::JOB_POST_TYPE,                             // Your custom post-type identifier,
                'post_excerpt' => get_jobpost('excerpt'),
                'post_date'    => get_jobpost('created'),
            ];

            if (!$wp_post_id) {

                // --- Post does not exist, create it ---
                $inserted_post_id = wp_insert_post($post_data, true);

                if (!$inserted_post_id || is_wp_error($inserted_post_id)) {
                    $message = "Bonsy_Recman_Post: Error creating job post for API ID $api_job_id. Error: " . (is_wp_error($inserted_post_id) ? $inserted_post_id->get_error_message() : 'Unknown error.');
                    error_log($message);
                    $logs[] = $message;
                    continue; // Skip to the next job post
                }

                // Add API ID and last_updated timestamp as custom fields.
                // Using constants for meta-keys is better
                update_post_meta($inserted_post_id, self::JOB_API_ID_META_KEY, $api_job_id);
                update_post_meta($inserted_post_id, self::LAST_UPDATED_META_KEY, $updated_timestamp);

                // Add additional custom fields
                foreach ($custom_fields as $meta_key) {
                    if ($meta_value = get_jobpost($meta_key)) {
                        update_post_meta($inserted_post_id, $meta_key, $meta_value);
                    }
                }

                // Set the featured image if available
                if (($image_url = get_jobpost('some_image')) && (strpos($image_url, 'http') !== false)) {
                    $this->set_featured_image_from_url($inserted_post_id, $image_url);
                }

                $logs[] = 'Job post created successfully. Post ID: ' . $inserted_post_id . '<br>';
                $processed_wp_post_ids_this_run[] = $inserted_post_id;

            } else {

                // --- Post exists, check for updates or re-publish if private ---
                $last_updated = (int)get_post_meta($wp_post_id, self::LAST_UPDATED_META_KEY, true);
                $current_post_status = get_post_status($wp_post_id);

                // Update if the RecMan timestamp is newer OR if the post is currently private (needs re-publishing)
                if ($updated_timestamp > $last_updated || $current_post_status === 'private') {

                    $post_data['ID'] = $wp_post_id;
                    $updated_post_id = wp_update_post($post_data, true); // Set true to return WP_Error on failure

                    if (!$updated_post_id || is_wp_error($updated_post_id)) {
                        $message = "Bonsy_Recman_Post: Error updating job post WP ID $wp_post_id (API ID $api_job_id). Error: " . (is_wp_error($updated_post_id) ? $updated_post_id->get_error_message() : 'Unknown error.');
                        error_log($message);
                        $logs[] = $message;
                        continue; // Skip to the next job post
                    }

                    // Update the post and its meta values here,
                    update_post_meta($wp_post_id, self::LAST_UPDATED_META_KEY, $updated_timestamp);

                    // Update/delete custom fields
                    foreach ($custom_fields as $meta_key) {
                        if ($meta_value = get_jobpost($meta_key)) {
                            update_post_meta($wp_post_id, $meta_key, $meta_value);
                        } else if (metadata_exists('post', $wp_post_id, $meta_key)) {
                            delete_post_meta($wp_post_id, $meta_key);
                        }
                    }

                    // Update featured image if URL is present and different (or re-set for private)
                    if (($image_url = get_jobpost('some_image')) && (strpos($image_url, 'http') !== false)) {
                        $this->set_featured_image_from_url($wp_post_id, $image_url);
                    }

                    if ($current_post_status === 'private') {
                        $logs[] = "Job post WP ID: $wp_post_id (API ID: $api_job_id) re-published.";
                    } else {
                        $logs[] = "Job post WP ID: $wp_post_id (API ID: $api_job_id) updated.";
                    }

                } else {
                    $logs[] = "Job post WP ID: $wp_post_id (API ID: $api_job_id) is already up to date and published.";
                    // Still mark as processed, as it's active
                }

                // Add to a processed list
                $processed_wp_post_ids_this_run[] = $wp_post_id;

            }

        } // End while (have_jobposts())

        // --- STEP 3 & 4: Identify and mark expired jobs as private ---
        // Get the WP post-IDs that were in the 'publish' state before this run
        // but were NOT found (processed) in the current API feed.
        $expired_wp_post_ids = array_diff(
            array_values($current_published_wp_job_posts), // Values are the WP Post IDs
            $processed_wp_post_ids_this_run,
        );

        if (!empty($expired_wp_post_ids)) {
            $logs[] = "Processing expired job posts:<br>";
            foreach ($expired_wp_post_ids as $expired_wp_id) {
                // Ensure we don't try to mark posts as private that are already private
                // (though `wp_update_post` handles this gracefully)
                $this->mark_job_post_as_private($expired_wp_id);
                $logs[] = "Marked job post WP ID: $expired_wp_id as private.<br>";
            }
        } else {
            $logs[] = "No expired job posts were found to mark as private.<br>";
        }

        return $logs;

    }



    /**
     * @param $job_post_id
     *
     * @return int|null
     */
    private function check_if_post_exists_by_api_id($job_post_id): ?int {

        $query = new WP_Query([
            'post_type'      => self::JOB_POST_TYPE, // Change to your custom post-type
            'meta_query'     => [
                [
                    'key'     => self::JOB_API_ID_META_KEY, // The custom field key
                    'value'   => $job_post_id,
                    'compare' => '=',
                ],
            ],
            'posts_per_page' => 1,
        ]);

        if ($query->have_posts()) {
            $query->the_post();      // Set up post-data
            $post_id = get_the_ID(); // Get the current post-ID
            wp_reset_postdata();     // Reset post data
            return $post_id ?: null; // Return the found post-ID
        }

        return null;
    }



    private function set_featured_image_from_url($post_id, $image_url): void {

        // Download image
        $tmp = download_url($image_url);

        // Check for download errors
        if (is_wp_error($tmp)) {
            // Handle error
            return;
        }

        $file_array = [
            'name'     => basename($image_url), // Set the image file name
            'tmp_name' => $tmp,                 // Set a file path to a temporary file
        ];

        // Upload the image file and create an attachment post
        $attachment_id = media_handle_sideload($file_array, $post_id);

        // Check for handle sideload errors.
        if (is_wp_error($attachment_id)) {
            @unlink($file_array['tmp_name']); // Clean up
            // Handle error
            return;
        }

        // Set the uploaded image as the featured image of the post
        set_post_thumbnail($post_id, $attachment_id);

    }



    /**
     * Helper method to fetch all currently published job_post IDs and their associated API IDs.
     *
     * @return array An associative array of [api_id => wp_post_id].
     * Returns an empty array if no published jobs are found.
     */
    private function get_published_job_posts_with_api_ids(): array {
        $published_jobs = [];
        $args = [
            // Using constants is better
            'post_type'              => self::JOB_POST_TYPE,
            'post_status'            => 'publish', // Only consider currently published posts
            'fields'                 => 'ids',     // Only retrieve post-IDs
            'posts_per_page'         => -1,        // Retrieve all matching posts
            'meta_query'             => [
                [
                    'key'     => self::JOB_API_ID_META_KEY,
                    'compare' => 'EXISTS', // Ensure the meta-key exists
                ],
            ],
            'no_found_rows'          => true,  // Optimization for queries where pagination isn't needed
            'update_post_meta_cache' => false, // Further optimization as we only need post-ID and meta_query already handled meta
            'update_post_term_cache' => false,
        ];

        $query = new WP_Query($args);

        if ($query->have_posts()) {
            foreach ($query->posts as $wp_id) {
                $api_id = get_post_meta($wp_id, self::JOB_API_ID_META_KEY, true);
                if ($api_id) {
                    $published_jobs[$api_id] = $wp_id;
                }
            }
        }
        wp_reset_postdata(); // Important: Reset the global post-data after a custom WP_Query
        return $published_jobs;
    }



    /**
     * Marks a WordPress job post as private.
     *
     * @param int $wp_post_id The WordPress post-ID.
     *
     * @return void True on success, false on failure.
     */
    private function mark_job_post_as_private(int $wp_post_id): void {
        if (get_post_status($wp_post_id) !== 'private') {
            $result = wp_update_post(['ID' => $wp_post_id, 'post_status' => 'private'], true);
            if (is_wp_error($result)) {
                error_log("Bonsy_Recman_Post: Failed to mark job post WP ID $wp_post_id as private. Error: " . $result->get_error_message());
            }
        }
    }



}

