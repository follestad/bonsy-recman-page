<?php
/**
 * The file that defines the plugin uninstallation
 *
 * @package RecMan\Includes
 */

defined('WPINC') || exit;


class Bonsy_Recman_Uninstaller {


    public static function uninstall(): void {
        if (!defined('WP_UNINSTALL_PLUGIN')) {
            throw new RuntimeException('WP_UNINSTALL_PLUGIN IS NOT DEFINED!');
        }
        self::factoryReset();
        Bonsy_Recman_Deactivator::deactivate();
    }



    /**
     * Factory reset - Delete all bonsy options (settings)
     */
    public static function factoryReset(): void {

        foreach ([
            'bonsy_license',
            'bonsy_demo',
            'bonsy_permalinks_updated',
            'bonsy_recman_api_key',
            'bonsy_show_job_locally',
            'bonsy_single_job_page',
            'bonsy_custom_job_path',
            'bonsy_expired_redirect',
            'bonsy_permission_check',
            'bonsy_filter_departments',
            'bonsy_filter_corporations',
            'bonsy_google_api_key',
            'bonsy_shortcode_active',
            'bonsy_shortcode_html_template',
            'bonsy_shortcode_custom_css',
            'bonsy_gutenberg_support',
            'bonsy_recman_custom_post_type_support',
            'bonsy_recman_cron_secret_key',
            'bonsy_version',
            'bonsy_await_fetch',
            'bonsy_expired_count',
        ] as $option) {
            delete_option($option);
        }

        flush_rewrite_rules();

    }



}
