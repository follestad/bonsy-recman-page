<?php
/**
 * The file that defines the plugin loading
 *
 * @package RecMan\Includes
 */

defined('WPINC') || exit;


class Bonsy_Recman_Loader {

    public Bonsy_Recman_Jobs $bonsy;



    /**
     * @throws Bonsy_Recman_Exception
     * @throws Exception
     */
    public function __construct() {

        # Load Bonsy RecMan Jobs
        $this->bonsy = new Bonsy_Recman_Jobs('wp-' . BONSY_RECMAN_PLUGIN_VERSION);
        $this->setBonsySettings();

        new Bonsy_Recman_Rewrite($this->bonsy);

        add_action('plugins_loaded', [$this, 'upgradePluginVersion'], 11, 0);

        add_action('plugins_loaded', function () {
            require_once BONSY_RECMAN_PLUGIN_DIR . '/includes/template.php';
            new Bonsy_Recman_Admin();

            # External flush of cache
            if (isset($_GET['flushRecManJobCache'])) {
                $this->bonsy->cacheDelete(true);
                die('RecMan cache has been deleted');
            }

        });

        add_action('get_header', function () {
            $this->bonsy->setPageUrl(get_permalink());
        });

        if (get_option('bonsy_show_job_locally')) {
            new Bonsy_Recman_Seo();
        }

        if (get_option('bonsy_recman_custom_post_type_support')) {
            new Bonsy_Recman_Post($this->bonsy);
        }

        # Load WP Template Helper
        add_action('wp_loaded', function () {
            //if (is_admin()) return;

            require_once BONSY_RECMAN_PLUGIN_DIR . '/includes/template.php';

            if (get_option('bonsy_shortcode_active')) {
                require_once BONSY_RECMAN_PLUGIN_DIR . '/includes/shortcode.php';
            }

            if (get_option('bonsy_gutenberg_support')) {
                new Bonsy_Recman_Gutenberg($this->bonsy);
            }

            do_action('bonsy_recman_plugin_loaded');
        });

        $this->disallowSearchEngines();

    }



    /**
     * @return void
     */
    public function upgradePluginVersion(): void {
        if (!Bonsy_Recman_Rewrite::job_post_page_id()) return;
        if (version_compare(get_option('bonsy_version'), BONSY_RECMAN_PLUGIN_VERSION, '<')) {
            update_option('bonsy_version', BONSY_RECMAN_PLUGIN_VERSION);
            flush_rewrite_rules();
        }
    }



    /**
     * If filters are activated, this can lead to crawling engines
     * overloads the site with too many requests. Block crawling of
     * job post page.
     *
     * @return void
     */
    public function disallowSearchEngines(): void {
        add_filter('robots_txt', static function (string $output, bool $public) {
            if (!$public) return $output;
            $output .= "Disallow: /*?jobs=*";
            $output .= "Disallow: /*?*jobs=*";
            return $output;
        }, 99, 2);
    }



    /**
     * Initialize Bonsy Recman Jobs API settings
     *
     * @return void
     * @throws Bonsy_Recman_Exception|DateInvalidTimeZoneException
     */
    private function setBonsySettings(): void {

        # Set Bonsy RecMan Jobs parameters
        $this->bonsy->setCacheFolder(BONSY_RECMAN_CACHE_DIR);

        if ($timezone = get_option('timezone_string')) {
            $this->bonsy->setTimezone($timezone);
        }

        $this->bonsy->setFilters($_GET ?? []);
        $this->bonsy->setDomain(get_site_url());


        if ($license = get_option('bonsy_license')) {
            $this->bonsy->setToken($license);
        } else {
            $this->bonsy->demo();
        }

        $this->bonsy->registerFetchErrorClosure(
            static function () {
                if (function_exists('update_option')) {
                    update_option('bonsy_await_fetch', time() + 1200);
                }
            },
            static function () {
                if (function_exists('update_option')) {
                    delete_option('bonsy_await_fetch');
                }
            },
        );

        // Await fetch if the server response was invalid
        if ($awaitTime = (int)get_option('bonsy_await_fetch')) {
            if ($awaitTime < time()) {
                delete_option('bonsy_await_fetch');
            } else {
                $this->bonsy->awaitNewFetch($awaitTime);
            }
        }

    }


}
