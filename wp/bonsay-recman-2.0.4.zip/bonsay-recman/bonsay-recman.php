<?php
/*
Plugin Name: Bonsy RecMan WP
Plugin URI: https://recman.bonsy.no/
Description: Integrate RecMan job posts to WordPress.
Version: 2.0.4
Author: Bonsy
Author URI: http://recman.bonsy.no/
Copyright: Bonsy
*/

if( ! defined( 'ABSPATH' ) ) exit; # Exit if accessed directly

if( ! class_exists( 'BonsyRecmanWp' ) and ! function_exists( 'recman' ) ) :

    class BonsyRecmanWp {

        const PLUGIN_VERSION = '2.0.4';

        public BonsyRecmanJobs $bonsy;




        /**
         * Plugin Constructor
         *
         * @throws \BonsyRecmanException
         * @throws \Exception
         */
        public function __construct() {

            # Load Bonsy RecMan Jobs
            require_once( $this->getFilePath( 'includes/BonsyRecmanJobs.php' ) );
            $this->bonsy = new BonsyRecmanJobs();

            # Set Bonsy RecMan Jobs parameters
            $this->bonsy->setCacheFolder( WP_CONTENT_DIR . "/cache/bonsy-recman/" );

            if( $timezone = get_option( 'timezone_string' ) ) {
                $this->bonsy->setTimezone( $timezone );
            }

            if( isset( $_GET['jobSearch'] ) ) {
                $_GET['searchData'] = $_GET['jobSearch'];
            }

            $this->bonsy->setFilters( $_GET ?? [] );

            if( $license = get_option( 'bonsy_license' ) ) {
                $this->bonsy->setToken( $license );
                $this->bonsy->load( [ 'domain' => get_site_url() ] );
            } else if( get_option( 'bonsy_demo' ) ) {
                $this->bonsy->demo();
                $this->bonsy->load( [ 'domain' => get_site_url() ] );
            }

            add_action( 'plugins_loaded', [ $this, 'init' ] );

        }




        /**
         * Initialize Plugin
         *
         * @throws \Exception
         */
        public function init() {

            require_once( $this->getFilePath( 'admin/admin.php' ) );

            add_action( 'init', [ $this, 'job_rewrite_rule' ], 10, 0 );
            add_action( 'pre_get_posts', [ $this, 'job_permalink_check' ], 0 );
            add_action( 'get_header', [ $this, 'seo' ] );

            add_action( 'get_header', function () {
                $this->bonsy->setPageUrl( get_permalink() );
            } );

            # Load WP Template Helper
            add_action( 'pre_get_posts', function () {
                if( is_admin() ) return;
                require_once( $this->getFilePath( 'includes/template.php' ) );
            } );

        }




        /**
         * Rewrite rule for pretty permalinks
         */
        public function job_rewrite_rule() {

            if( ! get_option( 'bonsy_show_job_locally' ) ) return;
            $page_id = get_option( 'bonsy_single_job_page' );
            if( empty( $page_id ) ) return;

            $slug = trim( $this->getPermalinkBaseUrl( $page_id, false ), '/' );

            add_rewrite_tag( '%recman_job_id%', '([^&]+)' );

            add_rewrite_rule( '^' . $slug . '/([^/]*)/?', 'index.php?page_id=' . $page_id . '&recman_job_id=$matches[1]', 'top' );

        }




        /**
         * Permalinks check
         */
        public function job_permalink_check() {

            global $wp_query;

            $permalink = $wp_query->query_vars['recman_job_id'] ?? null;

            if( is_null( $permalink ) ) return;

            $success = $this->bonsy->setCurrentJobByPermalink( trim( (string)$permalink, '/' ) );

            if( ! $success ) {
                $redirect = get_option( 'bonsy_expired_redirect' );
                $redirect = ( $redirect ) ? get_permalink( $redirect ) : get_site_url();
                if( ! headers_sent() and wp_redirect( $redirect ) ) {
                    exit;
                }
            }

        }




        /**
         * Load Job Post SEO for page
         *
         * @throws \Exception
         */
        public function seo() {
            $page_id = get_option( 'bonsy_single_job_page' );
            if( $page_id && is_page( intval( $page_id ) ) ) {
                require_once( $this->getFilePath( 'includes/seo.php' ) );
                $seo = new BonsyRecmanWpSeo();
                $seo->setPermalink( $this->getPermalinkBaseUrl( $page_id ) );
                $seo->load();
            }
        }




        /**
         * Get plugin file path
         *
         * @throws \Exception
         */
        public function getFilePath(string $file): string {
            $path = plugin_dir_path( __FILE__ ) . ltrim( $file, '/' );
            if( file_exists( $path ) && is_readable( $path ) ) {
                return $path;
            }
            throw new Exception( 'Bonsy RecMan WP Plugin file not found!: ' . $path );
        }




        /**
         * Get plugin file URL
         *
         * @param string $file
         *
         * @return string
         */
        public function getFileUrl(string $file = ''): string {
            return plugin_dir_url( __FILE__ ) . ltrim( $file, '/' );
        }




        /**
         * Generate Permalink
         *
         * @param int|null $id
         *
         * @return string|null
         */
        public function getPermalink(int $id = null): ?string {

            if( ! get_option( 'bonsy_show_job_locally' ) ) {
                return null;
            }

            $page_id = get_option( 'bonsy_single_job_page' );

            if( ! $page_id ) return null;

            $title = $this->bonsy->get( 'urn', $id );

            if( ! $title ) return null;

            $base = $this->getPermalinkBaseUrl( $page_id );

            return ( ! empty( $base ) ) ? "$base/$title/" : null;

        }




        /**
         * Get base URL for permalinks
         *
         * @param int $page_id
         * @param bool $include_site_url
         *
         * @return string
         */
        private function getPermalinkBaseUrl(int $page_id, bool $include_site_url = true): string {

            $base = get_permalink( $page_id );

            if( $custom = get_option( 'bonsy_custom_job_path' ) ) {
                $base = rtrim( get_site_url(), '/' ) . "/$custom";
            } else if( function_exists( 'wp_get_post_parent_id' ) && $parent = wp_get_post_parent_id( $page_id ) ) {
                $base = get_permalink( $parent );
            }

            if( ! $include_site_url ) {
                $base = str_replace( get_site_url(), '', $base );
            }

            return rtrim( $base, '/' );

        }




        /**
         * Echo Admin Icon
         *
         * @param $file
         *
         * @throws \Exception
         */
        public function icon($file): void {
            echo file_get_contents( $this->getFilePath( "admin/images/$file" ) );
        }




        /**
         * Factory reset - Delete all bonsy options (settings)
         */
        public static function factoryReset() {

            $list = [
                'bonsy_license',
                'bonsy_demo',
                'bonsy_permalinks_updated',
                'bonsy_recman_api_key',
                'bonsy_show_job_locally',
                'bonsy_single_job_page',
                'bonsy_custom_job_path',
                'bonsy_expired_redirect',
                'bonsy_permission_check',
                'bonsy_filter_departments',
                'bonsy_filter_corporations',
                'bonsy_version'
            ];

            $legacy = [
                'recman_token',
                'recman_demo_mode',
                'recman_filter_departments',
                'recman_filter_departmentList',
                'recman_department_last_fetched',
                'recman_job_page',
                'recman_job_page_custom_slug',
                'recman_job_page_slug',
                'recman_job_page_toggle',
                'recman_jobpost_page',
                'recman_jobpost_page_toggle',
                'recman_jobpost_page_slug',
                'recman_jobpost_page_custom_slug',
                'recman_expired_redirect',
                'recman_signup_url',
                'recman_permalinks_updated',
                'recman_coworker_last_fetched',
                'recman_jobpost_last_fetched'
            ];

            foreach( array_unique( array_merge( $list, $legacy ) ) as $option ) {
                delete_option( $option );
            }

        }




        /**
         * Plugin activation
         */
        public static function activate() {
            register_uninstall_hook( __FILE__, [ __CLASS__, 'uninstall' ] );
            flush_rewrite_rules();
        }




        /**
         * Plugin deactivation
         *
         * @throws \Exception
         */
        public static function deactivation() {
            self::deleteFolderWithFiles( WP_CONTENT_DIR . "/cache/bonsy-recman/" );
            flush_rewrite_rules();
        }




        /**
         * Plugin uninstall
         *
         * @throws \Exception
         */
        public static function uninstall() {
            self::factoryReset();
            self::deactivation();
        }




        /**
         * Delete folders wih files
         *
         * @param string $dir
         */
        private static function deleteFolderWithFiles(string $dir): void {

            $dir = rtrim( $dir, '/' );

            if( $dir && is_dir( $dir ) && function_exists( 'scandir' ) ) {

                $items = scandir( $dir );

                foreach( $items as $item ) {

                    if( $item == '.' || $item == '..' ) continue;

                    $item = $dir . '/' . $item;

                    if( is_file( $item ) ) {
                        unlink( $item );
                        continue;
                    }

                    if( is_dir( $item ) ) {
                        self::deleteFolderWithFiles( $item );
                    }

                }

                rmdir( $dir );

            }

        }


    }


    /*
    |-------------------------------------------------------------------------------
    | Start RecMan Jobs
    |-------------------------------------------------------------------------------
    | The main function responsible for returning the one true bonsayRecman Instance to
    | functions everywhere. Use this function like you would a global variable,
    | except without needing to declare the global.
    |
    | Example: <?php $acf = acf(); ?>
    */

    function recman(): BonsyRecmanWp {

        # globals
        global $recman;

        # initialize
        if( ! isset( $recman ) ) {
            $recman = new BonsyRecmanWp();
        }

        return $recman;

    }


    # initialize
    recman();

endif; # End check class_exists

register_activation_hook( __FILE__, [ 'BonsyRecmanWp', 'activate' ] );
register_deactivation_hook( __FILE__, [ 'BonsyRecmanWp', 'deactivation' ] );
