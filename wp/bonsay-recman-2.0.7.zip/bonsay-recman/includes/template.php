<?php /** @noinspection SpellCheckingInspection */

defined( 'ABSPATH' ) || die;


function get_jobpost_count(bool $filtered = true): int {
    return recman()->bonsy->countJobs( $filtered );
}


function get_jobpost_filters(string $field, bool $filtered = false): array {
    return recman()->bonsy->distinct( $field, $filtered );
}


function get_jobpost_position_count(bool $filtered = true): int {
    return recman()->bonsy->countPosition( $filtered );
}


function has_jobpost_filter(string $key, string $value = null): bool {
    return recman()->bonsy->hasFilter( $key, $value );
}


function have_jobposts(): bool {
    return recman()->bonsy->have_jobs();
}


function the_jobpost(string $field = null, int $id = null) {
    if( is_null( $field ) ) {
        return recman()->bonsy->the_job();
    }
    echo get_jobpost( $field );

}


function get_jobpost(string $field, int $id = null) {

    if( $field === 'permalink' ) {
        $permalink = recman()->getPermalink( $id );
        if( $permalink ) return $permalink;
        $field = 'apply';
    }

    return recman()->bonsy->get( $field, $id );
}


function have_jobpost_object(string $object): bool {
    return recman()->bonsy->have_object( $object );
}


function the_jobpost_object(string $field = null) {
    if( is_null( $field ) ) {
        return recman()->bonsy->the_object();
    }
    echo get_jobpost_object( $field );
}


function get_jobpost_object(string $field) {
    return recman()->bonsy->get_object( $field );
}


function get_jobpost_filter_url(string $key, string $value): string {
    return recman()->bonsy->getFilterUrl( $key, $value );
}