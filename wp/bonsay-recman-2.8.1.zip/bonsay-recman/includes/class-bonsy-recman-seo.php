<?php
/**
 * The file that defines the plugin SEO handling
 *
 * @package RecMan\Includes
 */

defined('WPINC') || exit;


class Bonsy_Recman_Seo {

    private string $permalink = '';



    /**
     * Load Job Post SEO for page
     */
    public function __construct() {
        add_action('wp', [$this, 'load']);
    }



    /**
     * Load SEO for a job post
     */
    public function load(): void {

        # Make sure individual job post is enabled
        $page_id = Bonsy_Recman_Rewrite::job_post_page_id();
        if (!$page_id || !is_page($page_id)) return;

        # Define permalink
        $url = Bonsy_Recman_Rewrite::get_permalink_base_url($page_id);
        $this->permalink = $url . '/' . $this->get('urn') . '/';

        # Remove oEmbed for job posts as we are not able to load content of post through oEmbed.
        remove_action('wp_head', 'wp_oembed_add_discovery_links');
        remove_action('wp_head', 'wp_oembed_add_host_js');

        $this->removeOtherSeoTools();

        $page_name = $this->get('name');

//        # Replace Page Title
        add_filter('document_title_parts', static function ($title_parts) use ($page_name) {
            $title_parts['title'] = $page_name;
            return $title_parts;
        });

        add_filter('wpseo_title', static function () use ($page_name) {
            return $page_name;
        });

        add_filter('pre_get_document_title', static function () use ($page_name) {
            return $page_name;
        });

        add_filter('the_title', static function () use ($page_name) {
            return $page_name;
        }, 10);

        # Another try to set a page title
        add_filter('wp_title', static function () use ($page_name) {
            return $page_name;
        });

        add_action('wp_head', [$this, 'metaData'], 1);

    }



    /**
     * Inject meta data
     */
    public function metaData(): void {

        # Remove The Page Title
        remove_action('wp_head', 'rel_canonical');

        echo "
            <!-- Job Social Tags -->
            <link rel='canonical' href='$this->permalink' />
            <meta name='description' content='" . $this->getDescription() . "' />
            <meta property='og:title' content='" . $this->getTitle() . "' />
            <meta property='og:description' content='" . $this->getDescription() . "' />
            <meta property='og:url' content='$this->permalink' />
            <meta property='og:site_name' content='" . get_bloginfo('name') . "' />
            <meta property='og:locale' content='" . get_locale() . "' />
            <meta property='og:type' content='article' />
            <meta name='article:published_time' content='" . $this->get('created') . "'/>
            <meta name='twitter:title' content='" . $this->getTitle() . "'/>
            <meta name='twitter:description' content='" . $this->getDescription() . "'/>
        ";

        if ($image = $this->get('some_image')) {
            echo "
                <meta property='og:image' content='$image' />
                <meta name='twitter:card' content='$image'/>
                <meta name='twitter:image' content='$image'/>
            ";
        }

        echo "<!-- End Job Social Tags -->";

    }



    private function get(string $field): string {
        return recman()->bonsy->get($field) ?? '';
    }



    private function getDescription(): string {
        $d = $this->get('some_description') ?: $this->get('excerpt');
        return trim(substr(strip_tags($d), 0, 250));
    }



    private function getTitle(): string {
        $title = $this->get('some_title');
        return $title ?: $this->get('name');
    }



    /**
     * Remove SEO Tools from the page
     *
     * @noinspection ClassConstantCanBeUsedInspection ClassConstantCanBeUsedInspection
     */
    public function removeOtherSeoTools(): void {

        # Remove SEO Framework
        add_filter('the_seo_framework_supported_post_type', static function () {
            return false;
        });

        # Remove Yoast
        if (function_exists('YoastSEO') && class_exists('\\Yoast\\WP\\SEO\\Integrations\\Front_End_Integration')) {
            add_action('template_redirect', static function () {
                try {
                    $front_end = YoastSEO()->classes->get(Yoast\WP\SEO\Integrations\Front_End_Integration::class);
                    remove_action('wpseo_head', [$front_end, 'present_head'], -9999);
                } catch (Throwable $e) {
                    # Do nothing!
                }
            });
        }

    }


}
