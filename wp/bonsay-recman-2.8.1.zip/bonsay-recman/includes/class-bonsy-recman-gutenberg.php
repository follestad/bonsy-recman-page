<?php
/**
 * The class that defines Gutenberg block functionality for job listings.
 *
 * @package RecMan
 * @subpackage RecMan/public
 */

defined('WPINC') || exit;

class Bonsy_Recman_Gutenberg {

    private Bonsy_Recman_Jobs $bonsy_jobs_api;

    public function __construct(Bonsy_Recman_Jobs $bonsy_jobs_api) {
        $this->bonsy_jobs_api = $bonsy_jobs_api;
        add_action('enqueue_block_editor_assets', [$this, 'enqueue_editor_assets']);
        add_action('init', [$this, 'register_blocks']);
        add_action('rest_api_init', [$this, 'register_rest_routes']);
    }

    /**
     * Enqueues scripts and styles for the Gutenberg editor.
     * This method is a more descriptive name for register_gutenberg_js_block.
     *
     * @return void
     */
    public function enqueue_editor_assets(): void {
        wp_enqueue_script(
            'recman-blocks',
            BONSY_RECMAN_PLUGIN_DIR_URL . 'block.js', // Assuming 'block.js' is in the root of the plugin directory
            ['wp-blocks', 'wp-i18n', 'wp-element', 'wp-components', 'wp-editor'],
            filemtime(BONSY_RECMAN_PLUGIN_DIR . '/block.js'), // Use BONSY_RECMAN_PLUGIN_DIR directly
            true // Enqueue in footer
        );
    }

    /**
     * Register a new block category for RecMan WP Plugin.
     *
     * @param array $categories Existing block categories.
     * @param WP_Post $post The current post-object.
     * @return array Modified block categories.
     */
    public function register_block_category(array $categories, WP_Post $post): array {
        return array_merge($categories, [[
            'slug' => 'recman-blocks',
            'title' => __('RecMan Job Post Blocks', 'recman'), // Use your text domain
            'icon' => 'dashicons-layout',
        ]]);
    }

    /**
     * Registers Gutenberg Block Type and adds block category filter.
     *
     * @return void
     */
    public function register_blocks(): void {
        add_filter('block_categories_all', [$this, 'register_block_category'], 10, 2);

        register_block_type('bonsy-recman/job-post-field', [
            'editor_script' => 'recman-blocks', // Use the handle we enqueued for the editor script
            'render_callback' => [$this, 'render_job_post_field_block'],
        ]);

        // You might have other blocks to register here.
        // For example,
        // register_block_type('bonsy-recman/job-list', [
        //     'editor_script' => 'recman-blocks',
        //     'render_callback' => [$this, 'render_job_list_block'],
        // ]);
    }

    /**
     * Handle rendering of a Gutenberg block for the front end.
     *
     * @param string $block_content The block content.
     * @param array $block The full block, including name and attributes.
     * @return string The rendered block content.
     */
    public function render_job_post_field_block(string $block_content, array $block): string {
        // Bail if not this block
        if ($block['blockName'] !== 'bonsy-recman/job-post-field') {
            return $block_content;
        }

        // Render content
        $field_name = $block['attrs']['jobPostFieldName'] ?? null; // Default to null if not set

        if ($field_name) {
            // Use the BonsyRecmanJobs instance passed in the constructor
            $job_data = $this->bonsy_jobs_api->get($field_name);
            return esc_html($job_data); // Sanitize output
        }

        return esc_html__('No field specified or data not available.', 'recman');
    }

    /**
     * Register REST API routes for fetching example data.
     *
     * @return void
     */
    public function register_rest_routes(): void {
        register_rest_route('bonsy-recman', '/job_post_field', array(
            'methods' => 'GET',
            'callback' => [$this, 'get_job_post_field_data'],
            'permission_callback' => function ($request) {
                // Only allow access to this API for authenticated users who can edit posts.
                // This is crucial for security.
                return current_user_can('edit_posts');
            },
            'args' => [
                'name' => [
                    'sanitize_callback' => 'sanitize_text_field',
                    'validate_callback' => function($param, $request, $key) {
                        return is_string($param) && !empty($param);
                    },
                    'required' => true,
                    'description' => 'The name of the job post field to retrieve.',
                ],
            ],
        ));
    }

    /**
     * Callback for the REST API route to fetch example job data.
     *
     * @param WP_REST_Request $request The REST API request.
     * @return string|WP_Error The field value or an error message.
     */
    public function get_job_post_field_data(WP_REST_Request $request) {
        $field = $request->get_param('name');

        if (empty($field)) {
            return new WP_Error(
                'bonsy_recman_missing_field',
                'Error: Missing "name" parameter.',
                ['status' => 400]
            );
        }

        // Set example data using the BonsyRecmanJobs instance
        // Assuming setExampleByFirstAvailableJob exists and populates a mock job.
        // This is primarily for the editor's preview.
        $this->bonsy_jobs_api->setExampleByFirstAvailableJob(); // You'll need to implement this method in BonsyRecmanJobs.

        $data = $this->bonsy_jobs_api->get($field);

        if (is_null($data)) {
            return new WP_Error(
                'bonsy_recman_invalid_field',
                "Invalid field '$field' or unable to fetch content.",
                ['status' => 404]
            );
        }

        return $data; // Return the raw data to the editor
    }
}