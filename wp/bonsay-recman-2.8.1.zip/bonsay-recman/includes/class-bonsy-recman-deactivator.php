<?php
/**
 * Plugin deactivation class
 *
 * @package RecMan\Includes
 */

defined('WPINC') || exit;


class Bonsy_Recman_Deactivator {


    public static function deactivate(): void {
        self::deleteCacheDirectory();
        flush_rewrite_rules();
    }



    /**
     * Deletes a directory and all its contents recursively.
     */
    private static function deleteCacheDirectory(): void {
        // Ensure the path is clean and exists before proceeding.
        $dirPath = rtrim(BONSY_RECMAN_CACHE_DIR, DIRECTORY_SEPARATOR);

        if (!is_dir($dirPath)) {
            return; // Directory doesn't exist, nothing to do.
        }

        // Use a RecursiveDirectoryIterator for a more robust and cleaner way to iterate.
        // This avoids potential issues with very deep directory structures and handles special files.
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($dirPath, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST,
        );

        foreach ($iterator as $path) {
            if ($path->isFile() || $path->isLink()) {
                @unlink($path->getRealPath());
            } else if ($path->isDir()) {
                @rmdir($path->getRealPath());
            }
        }

        // Finally, remove the top-level directory itself.
        @rmdir($dirPath);
    }



}
