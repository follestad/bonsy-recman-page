<?php
/**
 * The file that defines the plugin rewrite handling
 *
 * @package RecMan\Includes
 */

defined('WPINC') || exit;


class Bonsy_Recman_Rewrite {

    private Bonsy_Recman_Jobs $bonsy_jobs_api;



    public function __construct(Bonsy_Recman_Jobs $bonsy_jobs_api) {
        $this->bonsy_jobs_api = $bonsy_jobs_api;
        add_action('pre_get_posts', [$this, 'check_job_permalink'], 0);
        add_action('init', [$this, 'job_rewrite_rule'], 10, 0);
    }



    /**
     * Rewrite rule for pretty permalinks
     */
    public function job_rewrite_rule(): void {
        if ($page_id = Bonsy_Recman_Rewrite::job_post_page_id()) {
            $slug = trim(Bonsy_Recman_Rewrite::get_permalink_base_url($page_id, false), '/');
            $query = 'index.php?page_id=' . $page_id . '&recman_job_permalink=$matches[1]';
            add_rewrite_tag('%recman_job_permalink%', '([^&]+)');
            add_rewrite_rule('^' . $slug . '/([^/]*)/?', $query, 'top');
        }
    }



    /**
     * Get Single Job Page ID if activated
     *
     * @return int
     */
    public static function job_post_page_id(): int {
        return get_option('bonsy_show_job_locally')
            ? (int)get_option('bonsy_single_job_page')
            : 0;
    }



    /**
     * Permalinks check
     */
    public function check_job_permalink(): void {

        global $wp_query;

        $permalink = $wp_query->query_vars['recman_job_permalink'] ?? $_GET['recman_job_permalink'] ?? null;

        if (is_null($permalink)) return;

        if ($this->bonsy_jobs_api->setCurrentJobByPermalink(trim((string)$permalink, '/'))) return;

        $redirect = get_option('bonsy_expired_redirect');
        $redirect = ($redirect) ? get_permalink($redirect) : get_site_url();

        if (!headers_sent() && wp_redirect($redirect)) exit;
    }



    public static function get_permalink_base_url(int $page_id, bool $include_site_url = true): string {

        $base = get_permalink($page_id);

        if ($custom = get_option('bonsy_custom_job_path')) {
            $base = rtrim(get_site_url(), '/') . "/$custom";
        } else if (function_exists('wp_get_post_parent_id') && $parent = wp_get_post_parent_id($page_id)) {
            $base = get_permalink($parent);
        }

        if (!$include_site_url) {
            $base = str_replace(get_site_url(), '', $base);
        }

        return rtrim($base, '/');

    }


}
