<?php
/**
 * Bonsy RecMan WordPress Plugin
 *
 * @package       RecMan
 * @author        Bonsy
 *
 * @wordpress-plugin
 * Plugin Name:       Bonsy RecMan WP
 * Plugin URI:        https://recman.bonsy.no/
 * Description:       Auto-publish RecMan job posts to WordPress.
 * Version:           2.8.1
 * Author:            Bonsy
 * Author URI:        http://recman.bonsy.no/
 * Update URI:        http://recman.bonsy.no/
 * Copyright:         Bonsy AS
 * Text Domain:       bonsy-recman
 * Requires PHP:      7.4
 * Requires at least: 6.7
 */

// Exit if accessed directly
defined('WPINC') || exit;

// Define plugin constants
if (!defined('BONSY_RECMAN_PLUGIN_VERSION')) {
    define('BONSY_RECMAN_PLUGIN_VERSION', '2.8.1');
}

if (!defined('BONSY_RECMAN_PLUGIN_DIR')) {
    define('BONSY_RECMAN_PLUGIN_DIR', __DIR__);
}

if (!defined('BONSY_RECMAN_PLUGIN_DIR_URL')) {
    define('BONSY_RECMAN_PLUGIN_DIR_URL', plugin_dir_url(__FILE__));
}

if (!defined('BONSY_RECMAN_CACHE_DIR')) {
    define('BONSY_RECMAN_CACHE_DIR', WP_CONTENT_DIR . "/cache/bonsy-recman/");
}

/**
 * The core plugin class that is used to define admin-specific hooks,
 * and public-facing hooks.
 */

require_once BONSY_RECMAN_PLUGIN_DIR . '/includes/class-bonsy-recman-activator.php';
require_once BONSY_RECMAN_PLUGIN_DIR . '/includes/class-bonsy-recman-deactivator.php';
require_once BONSY_RECMAN_PLUGIN_DIR . '/includes/class-bonsy-recman-uninstaller.php';

require_once BONSY_RECMAN_PLUGIN_DIR . '/includes/class-bonsy-recman-loader.php';
require_once BONSY_RECMAN_PLUGIN_DIR . '/admin/class-bonsy-recman-admin.php';
require_once BONSY_RECMAN_PLUGIN_DIR . '/includes/class-bonsy-recman-rewrite.php';
require_once BONSY_RECMAN_PLUGIN_DIR . '/includes/class-bonsy-recman-jobs.php';
require_once BONSY_RECMAN_PLUGIN_DIR . '/includes/class-bonsy-recman-seo.php';
require_once BONSY_RECMAN_PLUGIN_DIR . '/includes/class-bonsy-recman-gutenberg.php';
require_once BONSY_RECMAN_PLUGIN_DIR . '/includes/class-bonsy-recman-updates.php';
require_once BONSY_RECMAN_PLUGIN_DIR . '/includes/class-bonsy-recman-post.php';


function recman(): Bonsy_Recman_Loader {

    # globals
    global $recman;

    # initialize
    if (!isset($recman)) {
        try {
            $recman = new Bonsy_Recman_Loader();
        } catch (Throwable $e) {

            // 1. Log the error (best practice)
            error_log('BonsyRecmanJobs initialization failed: ' . $e->getMessage());

            // 2. Display a user-friendly message in the admin area (if applicable)
            // You'd typically use WordPress admin notices for this.
            add_action('admin_notices', static function () use ($e) {
                echo '<div class="notice notice-error is-dismissible">';
                echo '<p><strong>BonsyRecmanJobs Plugin Error:</strong> ' . esc_html($e->getMessage()) . '</p>';
                echo '</div>';
            });

        }
    }

    return $recman;

}


// Kick off the plugin
recman();

// Register activation and deactivation hooks
register_activation_hook(__FILE__, ['Bonsy_Recman_Activator', 'activate']);
register_deactivation_hook(__FILE__, ['Bonsy_Recman_Deactivator', 'deactivate']);
register_uninstall_hook(__FILE__, ['Bonsy_Recman_Uninstaller', 'uninstall']);
