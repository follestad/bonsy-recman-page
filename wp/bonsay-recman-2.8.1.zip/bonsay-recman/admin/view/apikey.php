<?php if( !defined( 'ABSPATH' ) ) exit;

/** @noinspection PhpUnhandledExceptionInspection PhpUnhandledExceptionInspection */
$recman_plugin_license = recman()->bonsy->getLicense();
$recman_api_key = $recman_plugin_license['recman_api_key'] ?? 'n/a';

?>


    <div class='bonsay-block'>
        <div class="title"><h3>Update RecMan API Key</h3></div>
        <div class="inner">

            <!--suppress HtmlUnknownTarget -->
            <form method="post" action="options.php">

                <?php settings_fields( 'bonsy_recman_api_key_section' ); ?>

                <label for='bonsy_recman_api_key'>Recman API Key</label>
                <input name='bonsy_recman_api_key' id='bonsy_recman_api_key' type='text'
                       placeholder='<?= $recman_api_key ?>'/>

                <div class='buttons'>
                    <?php submit_button( 'Update Recman API key' ); ?>
                    <small>
                        <a href='https://app.recman.no/user/api.settings.php' target='_blank'>
                            <span class='dashicons dashicons-external'></span>
                            Open Recman API Settings
                        </a>
                    </small>
                </div>

            </form>

        </div>
    </div>

<?php