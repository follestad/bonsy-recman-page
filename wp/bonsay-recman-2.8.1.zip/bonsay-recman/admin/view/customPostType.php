<div class='bonsay-block'>
    <div class="title"><h3>Custom Post Type Support (BETA) (Advance)</h3></div>
    <div class="inner">

        <p>
            Enable this feature to automatically <em>import, update, and remove job posts</em> from your RecMan account directly into a new <em>"Job Post" custom post type</em> in WordPress.
            Once enabled, you'll need to decide how to display these job posts on your website. This typically involves using a <em>WordPress page builder</em> or custom development to show the "Job Post" custom fields (like job title, description, location, etc.) on your frontend.
        </p>

        <!--suppress HtmlUnknownTarget -->
        <form method="post" action="options.php">

            <?php settings_fields('bonsy_job_custom_post_type_section'); ?>

            <div id="local_job_page_settings" style="">

                <?php
                $bonsy_recman_custom_post_type_support = get_option('bonsy_recman_custom_post_type_support') ? 'checked' : '';
                $bonsy_recman_cron_secret_key = get_option('bonsy_recman_cron_secret_key');
                ?>

                <div class='recman-checkbox' style='display:block;margin-bottom: 1em;'>
                    <input type='checkbox' name='bonsy_recman_custom_post_type_support'
                           id='bonsy_recman_custom_post_type_support'
                           value='1' <?php echo $bonsy_recman_custom_post_type_support; ?> />
                    <label for='bonsy_recman_custom_post_type_support' class='checkboxlabel'><strong>Enable Custom Post
                            Type Support (Beta)</strong></label>
                </div>

                <?php if ($bonsy_recman_custom_post_type_support === 'checked') : ?>
                    <div class="warning info" style="margin: 2em 0">
                        <label for="bonsy_recman_cron_secret_key">
                            Set Up Automatic Sync (Cron Job)
                        </label>
                        <p>To keep your job posts synchronized with RecMan, you <em>must set up a cron job</em>. This cron job will regularly trigger your website to fetch and update the latest job information.</p>
                        <p>
                            Use the following <em>unique URL</em> for your cron job setup. Keep this URL private as it triggers your import process.
                        </p>
                        <p><strong>Cron Job URL:</strong>
                            <code><?php echo site_url('/bonsy-recman-cron/' . esc_html($bonsy_recman_cron_secret_key) . '/'); ?></code>
                        </p>
                    </div>

                    <div class="warning warning" style="margin: 2em 0">
                        <label for="bonsy_recman_cron_secret_key">
                            Regenerate Sync Key
                        </label>
                        <p>
                            If you ever suspect your <strong>Cron Job URL</strong> has been exposed or compromised, you can generate a new, secure key here. After regenerating, remember to <strong>update your cron job setup</strong> with the new URL.
                        </p>
                        <div class='recman-checkbox' style='display:block;margin-bottom: 1em;'>
                            <input type='checkbox' name='bonsy_regenerate_cron_key' id='bonsy_regenerate_cron_key' value='1' />
                            <label for='bonsy_regenerate_cron_key' class='checkboxlabel'><strong>Regenerate Sync Key</strong></label>
                        </div>
                    </div>

                <?php endif; ?>

            </div>

            <div class='buttons'>
                <?php submit_button('Save Changes'); ?>
            </div>

        </form>

    </div>
</div>