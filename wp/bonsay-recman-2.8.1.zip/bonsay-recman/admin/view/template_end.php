</section>

</div>

<aside>

    <?php

    /** @noinspection PhpUnhandledExceptionInspection */
    $license_details = recman()->bonsy->getLicense();
    $subscription = $license_details['subscription'] ?? true;

    if ($subscription === false) :

        /** @noinspection PhpUnhandledExceptionInspection */
        $expiry_date = recman()->bonsy->licenseExpiryDate();
        $expiry_date = $expiry_date->format(get_option('date_format'));

        ?>

        <div class="bonsy-cache" style="background-color: #D08770;">
            <h3 style="margin-top: 0">Trial Mode</h3>
            <p>Plugin is currently running trial mode. Please contact Bonsy to subscribe!</p>
            <p style="margin-bottom: 0"><small><strong>Trial expires:</strong><br> <?php echo $expiry_date; ?></small>
            </p>
        </div>

    <?php endif; ?>

    <?php if (get_option('bonsy_license') || get_option('recman_demo_mode')) :
        $delete_cache_url = wp_nonce_url(admin_url('admin.php?page=recman_settings&recman_delete_cache=1'), 'recman_delete_cache');
        try {
            $last_fetched = recman()->bonsy->lastFetchDate()
                ->format(get_option('date_format') . ' ' . get_option('time_format'));
        } catch (Exception $e) {
            $last_fetched = $e->getMessage();
        }
        ?>

        <div class="bonsy-cache">
            <p>Fetch recent RecMan data by resetting the cache</p>
            <a href='<?php echo $delete_cache_url; ?>' class='bonsy-button'>Reset cache</a>
            <?php if ($last_fetched) : ?>
                <div id="lastFetched">Last cache:<span><?php echo $last_fetched; ?></span></div>
            <?php endif; ?>
        </div>

    <?php endif; ?>

    <div class="bonsy-documentation">
        <i class="bonsay-icon-book">
            <svg aria-hidden="true" focusable="false" data-prefix="far" data-icon="book-open"
                 class="svg-inline--fa fa-book-open fa-w-20" role="img" xmlns="http://www.w3.org/2000/svg"
                 viewBox="0 0 640 512">
                <path fill="currentColor"
                      d="M561.91 0C549.44 0 406.51 6.49 320 56.89 233.49 6.49 90.56 0 78.09 0 35.03 0 0 34.34 0 76.55v313.72c0 40.73 32.47 74.3 73.92 76.41 36.78 1.91 128.81 9.5 187.73 38.69 8.19 4.05 17.25 6.29 26.34 6.58v.05h64.02v-.05c9.09-.29 18.15-2.53 26.34-6.58 58.92-29.19 150.95-36.78 187.73-38.69C607.53 464.57 640 431 640 390.27V76.55C640 34.34 604.97 0 561.91 0zM296 438.15c0 11.09-10.96 18.91-21.33 14.96-64.53-24.54-153.96-32.07-198.31-34.38-15.9-.8-28.36-13.3-28.36-28.46V76.55C48 60.81 61.5 48 78.06 48c19.93.1 126.55 7.81 198.53 40.49 11.63 5.28 19.27 16.66 19.28 29.44L296 224v214.15zm296-47.88c0 15.16-12.46 27.66-28.36 28.47-44.35 2.3-133.78 9.83-198.31 34.38-10.37 3.94-21.33-3.87-21.33-14.96V224l.14-106.08c.02-12.78 7.65-24.15 19.28-29.44C435.4 55.81 542.02 48.1 561.94 48 578.5 48 592 60.81 592 76.55v313.72z"></path>
            </svg>
        </i>
        <h3 class="bonsay-title2">Documentation</h3>
        <p>Get helpful information and answers to common issues.</p>
        <a href="https://bonsy.gitbook.io/bonsay-recman-wp/" target="_blank" class="bonsy-button">Read
            documentation</a>
    </div>

    <div class="bonsy-support">
        <i class="bonsay-icon-book">
            <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="user-headset" class="svg-inline--fa fa-user-headset fa-w-14" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M320 352h-23.1a174.08 174.08 0 0 1-145.8 0H128A128 128 0 0 0 0 480a32 32 0 0 0 32 32h384a32 32 0 0 0 32-32 128 128 0 0 0-128-128zM48 224a16 16 0 0 0 16-16v-16c0-88.22 71.78-160 160-160s160 71.78 160 160v16a80.09 80.09 0 0 1-80 80h-32a32 32 0 0 0-32-32h-32a32 32 0 0 0 0 64h96a112.14 112.14 0 0 0 112-112v-16C416 86.13 329.87 0 224 0S32 86.13 32 192v16a16 16 0 0 0 16 16zm160 0h32a64 64 0 0 1 55.41 32H304a48.05 48.05 0 0 0 48-48v-16a128 128 0 0 0-256 0c0 40.42 19.1 76 48.35 99.47-.06-1.17-.35-2.28-.35-3.47a64.07 64.07 0 0 1 64-64z"></path></svg>
        </i>
        <h3 class="bonsay-title2">Support</h3>
        <p>Experiencing an issue, found a bug or want to know more about the plugin?</p>
        <div>
            <div>kristoffer@bonsy.no</div>
            <div>+47 97156620</div>
        </div>
    </div>

</aside>

</main>

</div>