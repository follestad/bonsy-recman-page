<div class='bonsay-block'>
    <div class="title"><h3>Subscription</h3></div>
    <div class="inner">
        <p>
            Using this plugin requires an active subscription to work. The subscription is billed annually. To cancel
            your subscription you need to contact Bonsy.
            Email us at kristoffer@bonsy.no or call us at +47 97156620 to cancel your subscription.
        </p>
    </div>
</div>