<?php if (!defined('ABSPATH')) {
    exit;
}


class Bonsy_Recman_Admin {


    public function __construct() {
        add_action('init', [$this, 'init']);
    }



    public function init(): void {

        # Make sure a user is logged in
        if (!is_user_logged_in()) return;

        # Show the admin bar and delete cache if requested
        if (current_user_can('edit_others_pages')) {
            add_action('admin_bar_menu', [$this, 'adminTopBarMenu'], 99);
        }

        # Check if the cache should be deleted
        if (isset($_GET['recman_delete_cache']) && check_admin_referer('recman_delete_cache')) {
            $this->deleteCache();
        }

        # Bail if not admin panel
        if (!is_admin()) return;

        # Show a cache success message if transient is registered
        if ($noticeData = get_transient('bonsy-cache-reset-notice-' . get_current_user_id())) {
            $this->notice($noticeData['type'] ?? 'warning', $noticeData['message'] ?? 'Unable to get result from cache reset for Bonsy RecMan Plugin');
            delete_transient('bonsy-cache-reset-notice-' . get_current_user_id());
        }

        # Activate Plugin Updates
        if (current_user_can('update_plugins')) {
            new Bonsy_Recman_Updates();
        }

        if (current_user_can('manage_options')) {
            add_action('admin_enqueue_scripts', [$this, 'adminScripts']);
            add_action('admin_menu', [$this, 'adminMenu']);
            add_action('admin_init', [$this, 'adminSettings']);
            add_action('admin_init', [$this, 'maybeFlushRewriteRules']);
        }


    }



    private function deleteCache(): void {

        $error = null;

        try {
            recman()->bonsy->cacheDelete(true);
        } catch (Throwable $e) {
            $error = $e->getMessage();
        }

        if (Bonsy_Recman_Rewrite::job_post_page_id()) {
            flush_rewrite_rules();
        }

        # Use persistent notice if the user cannot access plugin admin
        if (!current_user_can('manage_options')) {
            set_transient('bonsy-cache-reset-notice-' . get_current_user_id(), [
                'type'    => $error ? 'error' : 'success',
                'message' => $error ?: 'Job post cache has been reset',
            ], 10);
            wp_redirect(admin_url());
            exit;
        }

        $this->notice($error ? 'error' : 'success', $error ?: 'Job post cache has been reset');

    }



    /**
     * Add a menu to the top bar in admin
     *
     * @param WP_Admin_Bar $wp_admin_bar
     */
    public function adminTopBarMenu(WP_Admin_Bar $wp_admin_bar): void {

        # Define Admin Bar Title
        $wp_admin_bar->add_menu([
            'parent' => false,
            'id'     => 'recman',
            'title'  => 'RecMan Jobs',
        ]);

        # Delete RecMan Cache
        $wp_admin_bar->add_menu([
            'parent' => 'recman',
            'id'     => 'recman-delete-cache',
            'title'  => 'Delete cache',
            'href'   => wp_nonce_url(admin_url('admin.php?page=recman_settings&recman_delete_cache=1'), 'recman_delete_cache'),
        ]);

        # Menu items below this must have this permission
        if (current_user_can('manage_options')) {
            $wp_admin_bar->add_menu([
                'parent' => 'recman',
                'id'     => 'recman-settings',
                'title'  => 'Settings',
                'href'   => admin_url('admin.php?page=recman_settings'),
            ]);
        }

    }



    /**
     * Include admin CSS and JS scripts
     *
     * @param $hook_suffix
     */
    public function adminScripts($hook_suffix): void {
        if ($hook_suffix !== 'toplevel_page_recman_settings') return;
        wp_enqueue_style(
            'bonsy-recman-admin-style',
            BONSY_RECMAN_PLUGIN_DIR_URL . 'admin/css/bonsy-admin-style.css',
        );
    }



    /**
     * Show RecMan Jobs in an admin panel menu
     */
    public function adminMenu(): void {
        add_menu_page(
            'RecMan Settings',
            'RecMan Jobs',
            'manage_options',
            'recman_settings', [&$this, 'adminView'],
            BONSY_RECMAN_PLUGIN_DIR_URL . '/admin/images/recman.svg',
            100,
        );
    }



    /**
     * Show an admin notice / warning message
     *
     * @param string $type
     * @param string $message
     */
    public function notice(string $type, string $message): void {
        add_action('admin_notices', static function () use ($type, $message) {
            echo "<div class='notice notice-$type is-dismissible'><p>$message</p></div>";
        });
    }



    /**
     * Validate RecMan API Key Permission Notice
     *
     * @param bool $output_success
     */
    private function validateApiKeyPermissionNotice(bool $output_success = false): void {

        if (!get_option('bonsy_license')) {
            delete_option('bonsy_permission_check');
            return;
        }

        if (!recman()->bonsy->tokenIsSet()) return;

        try {
            recman()->bonsy->validateRecmanApiKey();
            if ($output_success) {
                $this->notice('success', "Your registered RecMan API key seems to be safe.");
            }
            update_option('bonsy_permission_check', date('m'));
        } catch (Bonsy_Recman_Exception $e) {
            $this->permissionWarningNotice($e->getMessage());
            update_option('bonsy_permission_check', $e->getMessage());
        }
    }



    /**
     * Show Warning about RecMan API key permission
     *
     * @param string $message
     */
    private function permissionWarningNotice(string $message): void {
        $button_url = wp_nonce_url(admin_url('admin.php?page=recman_settings&view=license&bonsy_validate_permission=1'), 'bonsy_validate_permission');
        $this->notice('warning', rtrim($message, ' .') . ". <a href='$button_url'>Click here to check RecMan API permission again</a>");
    }



    /**
     * Admin Actions
     *
     * @throws Exception
     * @noinspection NestedPositiveIfStatementsInspection NestedPositiveIfStatementsInspection
     */
    public function adminActions(): void {

        # Factory Reset
        if (isset($_GET['bonsy_factory_reset']) && check_admin_referer('bonsy_factory_reset')) {
            Bonsy_Recman_Uninstaller::factoryReset();
            $this->notice('success', 'Bonsy RecMan WP Plugin has been reset');
        }

        # Validate API Key Permission
        if (isset($_GET['bonsy_validate_permission']) && check_admin_referer('bonsy_validate_permission')) {
            $this->validateApiKeyPermissionNotice(true);
        } else if (get_option('bonsy_license') && $permission_state = get_option('bonsy_permission_check')) {
            if ($permission_state !== date('m')) {
                if (strlen((string)$permission_state) > 5) {
                    $this->permissionWarningNotice((string)$permission_state);
                } else {
                    $this->validateApiKeyPermissionNotice();
                }
            }
        }

        if (isset($_GET['view']) && $_GET['view'] === 'save_api_settings') {
            $this->saveFetchSettings(array_merge($_GET ?? [], $_POST ?? []));
        }

        # Trigger of bonsy to check if fetch is available
        recman()->bonsy->getLicense();

        if ($error = recman()->bonsy->getError()) {
            $this->notice('error', $error);
        }

    }



    /**
     * Show RecMan Jobs Admin Page
     *
     * @throws Exception
     */
    public function adminView(): void {

        $this->adminActions();

        $view = $_GET['view'] ?? null;
        $license = get_option('bonsy_license');
        $demo_mode = get_option('bonsy_demo');

        require_once BONSY_RECMAN_PLUGIN_DIR . '/admin/view/template_start.php';

        # Registration Page
        if (!$license && !$demo_mode) {
            require_once BONSY_RECMAN_PLUGIN_DIR . '/admin/view/welcome.php';
            require_once BONSY_RECMAN_PLUGIN_DIR . '/admin/view/register.php';
            require_once BONSY_RECMAN_PLUGIN_DIR . '/admin/view/demoMode.php';
        } else if ($view === 'viewCache') {
            require_once BONSY_RECMAN_PLUGIN_DIR . '/admin/view/jsonCache.php';
        } else if ($view === 'shortcode') {
            require_once BONSY_RECMAN_PLUGIN_DIR . '/admin/view/shortcode.php';
        } else if ($view === 'changelog') {
            require_once BONSY_RECMAN_PLUGIN_DIR . '/admin/view/changelog.php';
        } else if ($view === 'license') {
            require_once BONSY_RECMAN_PLUGIN_DIR . '/admin/view/license.php';
            require_once BONSY_RECMAN_PLUGIN_DIR . '/admin/view/subscription.php';
            require_once BONSY_RECMAN_PLUGIN_DIR . '/admin/view/apikey.php';
            require_once BONSY_RECMAN_PLUGIN_DIR . '/admin/view/reset.php';
        } else if ($demo_mode) {
            require_once BONSY_RECMAN_PLUGIN_DIR . '/admin/view/demoMode_disable.php';
            require_once BONSY_RECMAN_PLUGIN_DIR . '/admin/view/jobPages.php';
            require_once BONSY_RECMAN_PLUGIN_DIR . '/admin/view/customPostType.php';
            require_once BONSY_RECMAN_PLUGIN_DIR . '/admin/view/caching.php';
            require_once BONSY_RECMAN_PLUGIN_DIR . '/admin/view/reset.php';
        } else if ($license) {
            require_once BONSY_RECMAN_PLUGIN_DIR . '/admin/view/fetchSettings.php';
            require_once BONSY_RECMAN_PLUGIN_DIR . '/admin/view/jobPages.php';
            require_once BONSY_RECMAN_PLUGIN_DIR . '/admin/view/customPostType.php';
            require_once BONSY_RECMAN_PLUGIN_DIR . '/admin/view/caching.php';
        }

        require_once BONSY_RECMAN_PLUGIN_DIR . '/admin/view/template_end.php';

    }



    /**
     * Add Register Sections
     *
     * @param string $name
     * @param callable $callback
     */
    private function addSection(string $name, callable $callback): void {
        $name .= '_section';
        add_settings_section($name, $name, static function () {}, 'recman_settings');
        $callback($name);
    }



    /**
     * RecMan Admin settings
     */
    public function adminSettings(): void {

        $this->addSection('bonsy_license', function ($section) {
            register_setting($section, 'bonsy_license', [
                'sanitize_callback' => [$this, 'validateRegistration'],
            ]);
        });

        $this->addSection('bonsy_recman_api_key', function ($section) {
            register_setting($section, 'bonsy_recman_api_key', [
                'sanitize_callback' => [$this, 'updateRecmanApiKey'],
            ]);
        });

        $this->addSection('bonsy_demo', function ($section) {
            register_setting($section, 'bonsy_demo', 'boolean');
        });

        if (!get_option('bonsy_recman_cron_secret_key')) {
            update_option('bonsy_recman_cron_secret_key', wp_generate_password(32, false));
        }

        $this->addSection('bonsy_job_page', function ($section) {
            register_setting($section, 'bonsy_show_job_locally', 'boolean');
            register_setting($section, 'bonsy_single_job_page', static function ($value) {
                update_option('bonsy_permalinks_updated', time());
                return (int)$value;
            });
            register_setting($section, 'bonsy_custom_job_path', [
                'sanitize_callback' => [$this, 'validateCustomSlug'],
            ]);
            register_setting($section, 'bonsy_expired_redirect', 'integer');
            register_setting($section, 'bonsy_google_api_key', 'string');
            register_setting($section, 'bonsy_gutenberg_support', 'boolean');
            register_setting($section, 'bonsy_recman_custom_post_type_support', 'boolean');
        });

        $this->addSection('bonsy_job_custom_post_type', function ($section) {
            register_setting($section, 'bonsy_recman_custom_post_type_support', 'boolean');
            register_setting($section, 'bonsy_regenerate_cron_key', function ($value) {
                if( $value ) {
                    update_option('bonsy_recman_cron_secret_key', wp_generate_password(32, false));
                    update_option('bonsy_recman_cron_key_regenerated', time());
                    $this->flushPermalinks();
                }
            });
        });

        # Flush Permalinks on change
        add_action('update_option_bonsy_show_job_locally', [$this, 'flushPermalinks'], 10, 2);
        add_action('update_option_bonsy_custom_job_path', [$this, 'flushPermalinks'], 10, 2);
        add_action('update_option_bonsy_expired_redirect', [$this, 'flushPermalinks'], 10, 2);
        add_action('update_option_bonsy_recman_custom_post_type_support', [$this, 'flushPermalinks'], 10, 2);

        $this->addSection('bonsy_shortcode', function ($section) {
            register_setting($section, 'bonsy_shortcode_active', 'boolean');
            register_setting($section, 'bonsy_shortcode_html_template', 'string');
            register_setting($section, 'bonsy_shortcode_custom_css', 'string');
        });

    }



    /**
     * Flush permalinks
     */
    public function flushPermalinks(): void {
        update_option('bonsy_permalinks_updated', time());
    }



    /**
     * Maybe flush rewrite rules
     */
    public function maybeFlushRewriteRules(): void {

        $lastUpdated = get_option('bonsy_permalinks_updated');

        if ($lastUpdated && $lastUpdated > strtotime('-1 hour')) {
            flush_rewrite_rules();
            $this->notice('success', 'Permalinks have been flushed.');
            delete_option('bonsy_permalinks_updated');
        }

        if (get_option('bonsy_recman_cron_key_regenerated')) {
            $this->notice('success', "Your auto-sync cron key has been regenerated.");
            delete_option('bonsy_recman_cron_key_regenerated');
        }

    }



    /**
     * Validate Registration
     *
     * @param string|null $token
     *
     * @return string|null
     */
    public function validateRegistration(string $token = null): ?string {

        if (empty($token)) {
            add_settings_error('bonsy_license', 'invalid-access', 'RecMan API key cannot be empty');
            return null;
        }

        try {
            return recman()->bonsy->register($token);
        } catch (Bonsy_Recman_Exception $e) {
            add_settings_error('bonsy_license', 'invalid-access', $e->getMessage() . ': ' . $token);
            return null;
        }

    }



    /**
     * Sanitize & update RecMan API key
     *
     * @param string|null $token
     *
     * @return bool
     * @throws Exception
     */
    public function updateRecmanApiKey(string $token = null): bool {

        if (empty($token)) {
            add_settings_error('bonsy_recman_api_key', 'invalid-access', 'RecMan API key cannot be empty');
        } else {
            try {
                $result = recman()->bonsy->updateRecmanApiKey($token);
                recman()->bonsy->cacheDelete(true);
                return $result;
            } catch (Bonsy_Recman_Exception $e) {
                add_settings_error('bonsy_recman_api_key', 'invalid-access', $e->getMessage() . '. Using API key: ' . $token);
            }
        }
        return false;
    }



    /**
     * Sanitize Custom Slug
     *
     * @param string|null $slug
     *
     * @return string|null
     */
    public function validateCustomSlug(string $slug = null): ?string {

        if (empty($slug)) return null;

        $slug = trim(trim($slug), '/');
        $slug = sanitize_title($slug);

        return (!empty($slug)) ? $slug : null;

    }



    /**
     * Save fetch settings
     *
     * @param array $settings
     *
     * @throws Exception
     */
    public function saveFetchSettings(array $settings): void {

        try {

            # Include Department Filters
            if (isset($settings['department'], $settings['bonsy_filter_departments'])) {
                update_option('bonsy_filter_departments', true);
                $settings['departmentIds'] = implode(',', $settings['departmentIds'] ?? []);
            } else {
                update_option('bonsy_filter_departments', false);
                $settings['departmentIds'] = '';
            }

            # Include Corporations Filters
            if (isset($settings['corporation'], $settings['bonsy_filter_corporations'])) {
                update_option('bonsy_filter_corporations', true);
                $settings['corporationIds'] = implode(',', $settings['corporationIds'] ?? []);
            } else {
                update_option('bonsy_filter_corporations', false);
                $settings['corporationIds'] = '';
            }

            $expire_count = $settings['includeExpiredCount'] ?? 0;
            update_option('bonsy_expired_count', $expire_count);

            unset($settings['view'], $settings['bonsy_filter_departments'], $settings['bonsy_filter_corporations']);

            recman()->bonsy->updateSettings($settings);
            recman()->bonsy->cacheDelete(true);
            $this->notice('success', 'Settings has been saved');

        } catch (Bonsy_Recman_Exception $e) {
            $this->notice('error', $e->getMessage());
        }

    }


}

