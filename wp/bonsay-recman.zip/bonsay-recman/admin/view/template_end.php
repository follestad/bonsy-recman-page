</section>

</div>

<aside>

    <?php

    $license_details = recman()->bonsy->getLicense();
    $subscription = $license_details['subscription'] ?? true;

    if( $subscription === false ) :

        $expiry_date = recman()->bonsy->licenseExpiryDate();
        $expiry_date = $expiry_date->format( get_option( 'date_format' ) );

        ?>

        <div class="bonsy-cache" style="background-color: #D08770;">
            <h3 style="margin-top: 0">Trial Mode</h3>
            <p>Plugin is currently running trial mode. Please contact Bonsy to subscribe!</p>
            <p style="margin-bottom: 0"><small><strong>Trial expires:</strong><br> <?php echo $expiry_date; ?></small>
            </p>
        </div>

    <?php endif; ?>

    <?php if( get_option( 'bonsy_license' ) or get_option( 'recman_demo_mode' ) ) :
        $delete_cache_url = wp_nonce_url( admin_url( 'admin.php?page=recman_settings&recman_delete_cache=1' ), 'recman_delete_cache' );
        $last_fetched = recman()->bonsy->lastFetchDate()
            ->format( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) );
        ?>

        <div class="bonsy-cache">
            <p>Fetch recent RecMan data by resetting the cache</p>
            <a href='<?php echo $delete_cache_url; ?>' class='bonsy-button'>Reset cache</a>
            <?php if( $last_fetched ) : ?>
                <div id="lastFetched">Last cache:<span><?php echo $last_fetched; ?></span></div>
            <?php endif; ?>
        </div>

    <?php endif; ?>

    <div class="bonsy-documentation">
        <i class="bonsay-icon-book"><?php recman()->icon( 'book-open-regular.svg' ); ?></i>
        <h3 class="bonsay-title2">Documentation</h3>
        <p>Get helpful information and answers to common issues.</p>
        <a href="https://bonsy.gitbook.io/bonsay-recman-wp/" target="_blank" class="bonsy-button">Read
            documentation</a>
    </div>

    <div class="bonsy-support">
        <i class="bonsay-icon-book"><?php recman()->icon( 'user-headset-solid.svg' ); ?></i>
        <h3 class="bonsay-title2">Support</h3>
        <p>Experiencing an issue, found a bug or want to know more about the plugin?</p>
        <div>
            <div>kristoffer@bonsy.no</div>
            <div>+47 97156620</div>
        </div>
    </div>

</aside>

</main>

</div>