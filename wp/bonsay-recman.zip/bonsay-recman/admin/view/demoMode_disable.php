<?php if( ! defined( 'ABSPATH' ) ) exit; ?>

<div class='bonsay-block'>
    <div class="title"><h3>You are running demo mode</h3></div>
    <div class="inner">

        <form method="post" action="options.php">
            <?php
            settings_fields( 'bonsy_demo_section' );
            $checked = get_option( 'bonsy_demo' ) ? 'checked' : '';
            ?>

            <p>
                Turn off demo mode to start fetching real data via your RecMan API key
            </p>

            <input type='hidden' name='bonsy_demo' id='bonsy_demo' value='0' />

            <div class='buttons'>
                <?php submit_button( 'Turn off demo mode' ); ?>
            </div>

        </form>
    </div>
</div>