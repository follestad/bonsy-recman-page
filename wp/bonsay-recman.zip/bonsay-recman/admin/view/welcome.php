<?php /** @noinspection PhpUnhandledExceptionInspection */

if( ! defined( 'ABSPATH' ) ) exit; ?>

<div id="bonsy-welcome">
    <i class='close' id='closeWelcome'><span class='dashicons dashicons-no-alt'></span> </i>
    <figure>
        <div class='image'
             style="background-image: url('<?php echo recman()->getFileUrl( 'admin/images/rocket.svg' ); ?>')"></div>
    </figure>
    <div class="text">
        <h2>Welcome</h2>
        <p>
            Bonsy Recman WP Plugin makes it easy to show job posts from RecMan on your WordPress site.
            The plugin will automatically cache job posts locally for better performance and fewer API requests.
        </p>
        <p><a href="https://bonsy.gitbook.io/bonsay-recman-wp/" target="_blank">View Documentation</a></p>
    </div>
    <div class="waveDivider">
        <?php recman()->icon( 'wave.svg' ); ?>
    </div>
</div>


<script type="text/javascript">
    document.getElementById('closeWelcome').addEventListener("click", () => {
        document.getElementById('bonsy-welcome').remove();
    });
</script>
