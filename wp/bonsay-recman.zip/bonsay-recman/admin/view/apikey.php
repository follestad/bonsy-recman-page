<?php if( ! defined( 'ABSPATH' ) ) exit;

/** @noinspection PhpUnhandledExceptionInspection */
$recman_api_key = recman()->bonsy->getLicense();
$recman_api_key = $recman_api_key['recman_api_key'] ?? 'n/a';

?>


<div class='bonsay-block'>
    <div class="title"><h3>Update RecMan API Key</h3></div>
    <div class="inner">


        <!--suppress HtmlUnknownTarget -->
        <form method="post" action="options.php">
            <?php

            settings_fields( 'bonsy_recman_api_key_section' );

            echo "<label for='bonsy_recman_api_key'>Recman API Key</label>";
            echo "<input name='bonsy_recman_api_key' id='bonsy_recman_api_key' type='text' placeholder='$recman_api_key' />";

            echo "<div class='buttons'>";
            submit_button( 'Update Recman API key' );
            echo "<small><a href='https://app.recman.no/user/api.settings.php' target='_blank'><span class='dashicons dashicons-external'></span>Open Recman API Settings</a></small>";
            echo "</div>";

            ?>
        </form>

    </div>
</div>

<?php