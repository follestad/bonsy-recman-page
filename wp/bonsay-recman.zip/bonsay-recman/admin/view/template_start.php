<div id='bonsy-wrap'>
    <?php settings_errors(); ?>

    <main>

        <div id="bonsy-content">

            <header>

                <div id="bonsy-logo">
                    <a href='https://bonsay.no' target='_blank'>
                        <?php recman()->icon( 'bonsy_line.svg' ); ?>
                    </a>
                    <h1>RecMan Plugin</h1>
                </div>

                <nav>
                    <?php if( !get_option( 'bonsy_license' ) && !get_option( 'bonsy_demo' ) ) : ?>
                        <a href="<?php echo admin_url( 'admin.php?page=recman_settings' ); ?>">Register</a>
                    <?php else : ?>
                        <a href="<?php echo admin_url( 'admin.php?page=recman_settings' ); ?>">Settings</a>
                        <?php if( get_option( 'bonsy_license' ) ) : ?>
                            <a href="<?php echo admin_url( 'admin.php?page=recman_settings&view=license' ); ?>">License</a>
                        <?php endif; ?>
                        <a href="<?php echo admin_url( 'admin.php?page=recman_settings&view=shortcode' ); ?>">Shortcode</a>
                        <a href="<?php echo admin_url( 'admin.php?page=recman_settings&view=viewCache' ); ?>">View
                            cache</a>
                        <a href="<?php echo admin_url( 'admin.php?page=recman_settings&view=changelog' ); ?>">Changelog</a>
                    <?php endif; ?>
                </nav>
            </header>

            <section>
