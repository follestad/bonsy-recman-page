<div id='bonsy-wrap'>
    <?php settings_errors(); ?>

    <main>

        <div id="bonsy-content">

            <header>

                <div id="bonsy-logo">
                    <h1>RecMan WP</h1>
                    <span><a href='https://bonsay.no' target='_blank'>by Bonsy</a></span>
                </div>

                <nav>
                    <?php if( get_option( 'bonsy_license' ) ) : ?>
                        <a href="<?php echo admin_url('admin.php?page=recman_settings');?>">Settings</a>
                        <a href="<?php echo admin_url('admin.php?page=recman_settings&view=license');?>">License</a>
                        <a href="<?php echo admin_url('admin.php?page=recman_settings&view=viewCache');?>">View cache</a>
                    <?php else : ?>
                        <a href="<?php echo admin_url('admin.php?page=recman_settings');?>">Register</a>
                    <?php endif; ?>
                </nav>
            </header>

            <section>
