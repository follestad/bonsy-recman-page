<div class='bonsay-block'>
    <div class="title"><h3>Shortcode</h3></div>
    <div class="inner">

        <p>
            Display job posts using a shortcode <code>[job_post_feed]</code>. This can be a convenient option if you are
            not
            familiar with PHP or are using a theme builder such as Elementor, DIVI, or Flatsome.
        </p>

        <p>
            To limit the number of jobs displayed, use the shortcode <code>[job_post_feed count="10"]</code> to show
            only 10 jobs.
        </p>

        <form method="post" action="options.php">

            <?php

            settings_fields( 'bonsy_shortcode_section' );
            $checked = get_option( 'bonsy_shortcode_active' ) ? 'checked' : '';
            $style = $checked ? '' : 'display:none';

            $html_template = get_option( 'bonsy_shortcode_html_template' );

            if( ! $html_template || ! is_string( $html_template ) ) {
                $html_template = @file_get_contents( recman()->getFilePath( "admin/view/shortcode_html_example.html" ) ) ?: '';
                update_option( 'bonsy_shortcode_html_template', $html_template );
            }

            ?>

            <div class='recman-checkbox' style='display:block;margin-bottom: 1em;'>
                <input type='checkbox' name='bonsy_shortcode_active' id='bonsy_shortcode_active'
                       value='1' <?php echo $checked; ?> />
                <label for='bonsy_shortcode_active' class='checkboxlabel'><strong>Activate shortcode</strong></label>
            </div>

            <br>

            <div id="bonsy_shortcode_settings" style="<?php echo $style; ?>">

                <label for="bonsy_shortcode_html_template">Custom Job Post Feed HTML Template</label>
                <textarea name="bonsy_shortcode_html_template" class="bonsyTextArea"
                          id="bonsy_shortcode_html_template"><?php echo $html_template; ?></textarea>

                <div class="warning info" style="margin: 2em 0">
                    To add fields inside your template use <code>{{ field_name }}</code> where field_name is the name of
                    the field.
                    <a href="https://bonsy.gitbook.io/bonsay-recman-wp/job-posts/displaying-fields/untitled"
                       target="_blank">See available fields here</a>
                </div>


                <?php
                $css = get_option( 'bonsy_shortcode_custom_css', '' );
                if( ! $css || ! is_string( $css ) ) {
                    $css = @file_get_contents( recman()->getFilePath( "admin/css/shortcode_css_example.css" ) ) ?: '';
                    update_option( 'bonsy_shortcode_custom_css', $css );
                }
                ?>

                <label for="shortcode_css">Excerpt length</label>
                <textarea name="bonsy_shortcode_custom_css" class="bonsyTextArea"
                          id="shortcode_css"><?php echo $css; ?></textarea>

            </div>


            <div class='buttons' style="margin-top: 1rem">
                <?php submit_button( 'Save' ); ?>
            </div>

        </form>

        <script>

            const shortcode_css = document.getElementById('shortcode_css');
            const shortcode_html = document.getElementById('bonsy_shortcode_html_template');

            const autoGrow = (el) => {
                el.style.height = '1em';
                el.style.height = (el.scrollHeight) + "px";
            }

            document.addEventListener("DOMContentLoaded", function () {
                autoGrow(shortcode_css);
                autoGrow(shortcode_html);
            });

            shortcode_css.addEventListener('input', () => autoGrow(shortcode_css));
            shortcode_html.addEventListener('input', () => autoGrow(shortcode_html));

            const formTabSupport = (e) => {
                if (e.key == 'Tab') {
                    e.preventDefault();
                    let form = e.target;
                    let s = form.selectionStart;
                    form.value = form.value.substring(0, form.selectionStart) + "    " + form.value.substring(form.selectionEnd);
                    form.selectionEnd = s + 4;
                }
            }

            shortcode_css.addEventListener('keydown', function (e) {
                formTabSupport(e, this);
            });
            shortcode_html.addEventListener('keydown', function (e) {
                formTabSupport(e, this);
            });


            const shortCodeIsActive = document.getElementById('bonsy_shortcode_active');

            shortCodeIsActive.addEventListener('change', function () {
                if (shortCodeIsActive.checked) {
                    document.getElementById('bonsy_shortcode_settings').style.display = 'block';
                    autoGrow(shortcode_css);
                    autoGrow(shortcode_html);
                } else {
                    document.getElementById('bonsy_shortcode_settings').style.display = 'none';
                }
            });

        </script>

    </div>
</div>