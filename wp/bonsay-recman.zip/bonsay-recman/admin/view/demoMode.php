<?php if( ! defined( 'ABSPATH' ) ) exit; ?>

<div class='bonsay-block'>
    <div class="title"><h3>Demo mode</h3></div>
    <div class="inner">


        <form method="post" action="options.php">

            <p>
                If you are in a development stage and doesn't have job posts or a RecMan API key available, you can activate
                a demo mode to get started. The demo mode will use sample data from the Bonsy server.
            </p>

            <?php
            settings_fields( 'bonsy_demo_section' );
            $checked = get_option( 'bonsy_demo' ) ? 'checked' : '';
            ?>

            <input type='hidden' name='bonsy_demo' id='bonsy_demo' value='1'/>

            <div class='buttons'>
                <?php submit_button( 'Activate demo mode' ); ?>
            </div>

        </form>
    </div>
</div>