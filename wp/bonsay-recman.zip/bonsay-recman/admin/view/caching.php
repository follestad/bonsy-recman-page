<div class='bonsay-block'>
    <div class="title"><h3>Cache</h3></div>
    <div class="inner">
        <p>
            The plugin automatically caches job posts to optimize for speed and safety. The caching interval is tuned
            for higher frequency at the daytime hours. You can fetch the most recent Recman data by updating the cache.
        </p>

        <?php

        echo "<div class='buttons'>";
        echo "<a href='" . wp_nonce_url( admin_url( 'admin.php?page=recman_settings&recman_delete_cache=1' ), 'recman_delete_cache' ) . "' class='button button-primary'>Update cache</a>";
        echo "<small><a href='https://app.gitbook.com/@bonsay/s/bonsay-recman-wp/get-started/automatic-caching' target='_blank'><span class='dashicons dashicons-external'></span> Learn more</a></small>";
        echo "</div>";

        ?>
    </div>
</div>