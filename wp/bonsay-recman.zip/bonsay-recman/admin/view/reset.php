<div class='bonsay-block'>
    <div class="title"><h3>Plugin Reset</h3></div>
    <div class="inner">

        <div class="warning" style="margin-top: 0">
            <p>Delete all settings. This will delete license, cache and all settings.</p>
            <div class='recman-checkbox' style='display:block;margin-bottom: 1em;'>
                <input type='checkbox' id="show_delete_button" />
                <label for='show_delete_button'>Yes, I understand. Show me the delete button.</label>
            </div>
        </div>

        <?php

        echo "<a href='" . wp_nonce_url( admin_url( 'admin.php?page=recman_settings&bonsy_factory_reset=1' ), 'bonsy_factory_reset' ) . "' class='button button-secondary' id='delete_settings_button' style='display: none'>Delete all settings</a>";

        ?>

        <script>

            const showDeleteButton = document.getElementById('show_delete_button');

            showDeleteButton.addEventListener('change', function () {
                if( showDeleteButton.checked ) {
                    document.getElementById('delete_settings_button').style.display = 'inline-block';
                } else {
                    document.getElementById('delete_settings_button').style.display = 'none';
                }
            });

        </script>

    </div>
</div>
