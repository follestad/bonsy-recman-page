<div class='bonsay-block'>
    <div class="title"><h3>Changelog</h3></div>
    <div class="inner changelog">

        <h4>Oct 27, 2023 - v2.7.0</h4>
        <ul>
            <li>
                <strong>Pagination Support Added:</strong> New parameters <code>$count</code> and <code>$offset</code>
                have been added to <code>have_jobposts()</code> and <code>have_expired_jobposts()</code> for pagination.
                To calculate the offset, use: <code>$offset = ( $page_number - 1 ) * $posts_per_page;</code>. For
                example, to display 10 posts per page, the offset for page 3 should be 20:
                <code>have_jobposts( 10, 20)</code>
            </li>
            <li>
                <strong>BETA: Gutenberg Editor Support:</strong> Preliminary support for the Gutenberg editor is
                available for testing. Activation is required. This feature is not production-ready. Contact us for
                issues or feature requests.
            </li>
        </ul>

        <h4>Aug 22, 2023 - v2.6.0</h4>
        <ul>
            <li>
                <strong>Added Google Maps Integration:</strong> Users can now display a Google Map in job posts by
                setting up a Google API key in the settings page. Utilize the WordPress shortcode
                <code>[job_post_map]</code> or the helper function <code>job_post_map();</code> to embed the map.
            </li>
        </ul>

        <h4>Aug 2, 2023 - v2.5.4</h4>
        <ul>
            <li>
                <strong>Improved SEO data:</strong> oEmbed is disabled for single job posts as it is not possible for
                oEmbed to get content of job post. Site like LinkedIn will now ignore oEmbed and read the correct meta
                tags instead.
            </li>
        </ul>

        <h4>Jun 30, 2023 - v2.5.0</h4>
        <ul>
            <li>
                <strong>Implemented Shortcode Functionality for Job Post Fields:</strong> You can now extract specific
                job post fields with the newly added shortcode feature, for example, <code>[job_post_field
                    name="title"]</code>. This
                enhancement empowers you to craft individual job post pages with the help of shortcodes. This is
                particularly advantageous if you're leveraging theme builders like Elementor, Divi, etc.
            </li>
            <li>
                <strong>New Shortcode for Displaying Contact Persons:</strong> We've introduced a shortcode,
                <code>[job_post_contacts]</code>, to display contact persons in individual job posts. It uses a
                default HTML markup. We will add support for custom markup in the future.
            </li>
            <li><strong>Demo Mode improvements:</strong> We've expanded our admin page functionalities to include
                options for managing shortcodes, accessing the changelog, viewing cache, and deleting cache within the
                demo mode.
            </li>
        </ul>

        <h4>Feb 23, 2023 - v2.4.2</h4>
        <ul>
            <li>Added options for custom fields in shortcode</li>
            <li>Option to set custom "no job post available" text for shortcode using <code>no_job_post_message</code>
                attribute.
            </li>
        </ul>

        <h4>Jan 27, 2023 - v2.4.0</h4>
        <ul>
            <li>Added build-in support for shortcode. You can use the shortcode <code>[job_post_feed]</code> to list job
                posts. This must be activated in the settings and a custom CSS and HTML must be added.
            </li>
            <li>Improved handling of filters</li>
            <li>Count for filtered list will adjust according to filtered list</li>
            <li>Filter now support department names</li>
            <li>Added changelog to settings</li>
            <li>Better blocking of search engines for filtered results in job posts as this could lead to crawlers goes
                into loop.
            </li>
        </ul>

        <h4>Des 29, 2022 - v2.3.0</h4>
        <ul>
            <li>Option to sort jobs by created, updated or startDate</li>
        </ul>

    </div>
</div>