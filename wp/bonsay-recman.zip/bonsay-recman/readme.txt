=== Recman By Bonsy ===
Contributors: Bonsy
Tags: bonsy, recman, job posts
Requires at least: 6.0.0
Tested up to: 6.0.0
Requires PHP: 7.4

Automatically list RecMan job posts on your WordPress site.
