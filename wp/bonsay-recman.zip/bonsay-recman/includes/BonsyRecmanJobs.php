<?php


class BonsyRecmanException extends Exception {

}


class BonsyRecmanJobs {

    private const DEFAULT_LOOP_ID = 'jobs';
    private const PLUGIN_NAME     = 'Bonsy Recman Jobs Plugin';
    private const BASE_URL        = 'https://recman-api.bonsy.no/';
    private const PLUGIN_VERSION  = 'wp-2.0';

    /** User Settings */
    private string $token = '';
    private string $cache_folder = '';
    private bool $demo_mode = false;
    private array $filters = [];
    private string $pageUrl = '';

    /** Cache variables */
    private bool $isLoaded = false;
    private array $jobs = [];
    private array $jobs_filtered = [];
    private array $permalinks = [];
    private array $license = [];
    private array $updated = [];
    private array $settings = [];
    private array $departments = [];
    private array $corporations = [];
    private ?string $error = null;

    /** Class variables */
    private DateTime $date;
    private DateTimeZone $timezone;
    private array $valid_fields = [];

    /** Loop data */
    private array $loop = [];
    private array $loop_current = [];
    private ?string $current_object = null;




    /**
     * Class Construction
     *
     * @throws \Exception
     */
    public function __construct() {
        $this->timezone = new DateTimeZone( 'Europe/Oslo' );
        $this->date = new DateTime( 'now', $this->timezone );
    }


    /*
    |--------------------------------------------------------------------------
    | User Settings
    |--------------------------------------------------------------------------
    */

    /**
     * Change default timezone
     *
     * @param string $timezone
     *
     * @noinspection PhpUnused
     */
    public function setTimezone(string $timezone): void {
        $this->timezone = new DateTimeZone( $timezone );
        $this->date->setTimezone( $this->timezone );
    }




    /**
     * Set Token
     *
     * @param string $token
     *
     * @return $this
     * @noinspection PhpUnused
     */
    public function setToken(string $token): self {
        $this->token = $token;
        return $this;
    }




    /**
     * Check if token is set
     *
     * @return bool
     */
    public function tokenIsSet(): bool {
        return ! empty( $this->token );
    }




    /**
     * Set filters
     *
     * @param array $filters
     *
     * @return $this
     * @noinspection PhpUnused
     */
    public function setFilters(array $filters): self {
        $this->filters = $filters;
        return $this;
    }




    /**
     * Set Page URL
     *
     * @param string $url
     *
     * @noinspection PhpUnused
     */
    public function setPageUrl(string $url): void {
        $this->pageUrl = $url;
    }




    /**
     * Activate demo mode
     *
     * @param bool $use_demo_mode
     *
     * @noinspection PhpUnused
     */
    public function demo(bool $use_demo_mode = true): void {
        $this->demo_mode = $use_demo_mode;
    }



    /*
    |--------------------------------------------------------------------------
    | Load job data
    |--------------------------------------------------------------------------
    */

    /**
     * Load jobs from cache or through API
     *
     * @noinspection PhpUnused
     * @throws \BonsyRecmanException
     */
    public function load(array $settings = [], bool $force_reload = false): self {

        # Bail early if loaded
        if( $this->isLoaded && ! $force_reload ) return $this;

        if( ! $this->demo_mode ) $this->token();

        # Get cached date, or fetch, or use the latest cache available
        $jobs = $this->cacheContent() ?? $this->fetchJobs( $settings ) ?? $this->cacheLastContent();

        # Bail if no jobs are loaded
        if( empty( $jobs ) ) return $this;

        # Convert result to array
        try {
            $jobs = json_decode( $jobs, true, 512, JSON_THROW_ON_ERROR );
        } catch ( JsonException $e ) {
            return $this;
        }

        # Set data
        $this->isLoaded = true;
        $this->jobs = $jobs['result'] ?? [];
        $this->permalinks = $jobs['permalinks'] ?? [];
        $this->license = $jobs['license'] ?? [];
        $this->updated = $jobs['updated'] ?? [];
        $this->settings = $jobs['settings'] ?? [];
        $this->departments = $jobs['departments'] ?? [];
        $this->corporations = $jobs['corporations'] ?? [];

        if( isset( $jobs['success'], $jobs['message'] ) && $jobs['success'] === false ) {
            $this->error = $jobs['message'];
        }

        # Set valid fields
        foreach( $this->jobs as $job ) {
            $this->valid_fields = array_unique( array_merge( $this->valid_fields, array_keys( $job ) ) );
        }

        # Filter jobs
        $this->filterJobs();

        # Return class
        return $this;

    }




    /**
     * Filter Results
     *
     * This will take an array of filters.
     * If the key exists it will exclude jobs without the given value for that field.
     */
    private function filterJobs(): void {

        $this->jobs_filtered = $this->jobs;

        # Loop each job post
        foreach( $this->jobs_filtered as $key => $job ) {

            # Check each query
            foreach( $this->filters as $searchKey => $searchValues ) {

                # Replace search keys
                if( $searchKey === 'department' ) {
                    $searchKey = 'departmentId';
                }

                # Bail if not a valid field
                if( ! in_array( $searchKey, $this->valid_fields, true ) ) continue;

                if( empty( trim( $searchValues ) ) ) continue;

                # Split search by comma
                $searchValues = explode( ',', strtolower( trim( htmlspecialchars( $searchValues ) ) ) );

                # Define the current job value based on key
                # Lowercase + remove comma in values from job post field
                $jobValue = $job[$searchKey] ?? '';
                $jobValue = str_replace( ',', '', strtolower( trim( (string)$jobValue ) ) );

                # Check if job post field contains any of the given search query
                foreach( $searchValues as $searchValue ) {

                    if( $searchKey === 'searchData' ) {
                        $freeSearchValueItems = explode( ' ', trim( $searchValue ) );
                        foreach( $freeSearchValueItems as $freeSearchValueItem ) {
                            if( empty( trim( $freeSearchValueItem ) ) ) continue;
                            if( strpos( $jobValue, trim( $freeSearchValueItem ) ) !== false ) {
                                continue 3;
                            }
                        }
                    }


                    if( $searchValue === $jobValue ) {
                        continue 2;
                    }
                }

                # Remove job post as the query doesn't match the job post.
                unset( $this->jobs_filtered[$key] );

            }
        }

    }




    public function getError(): ?string {
        return $this->error;
    }


    /*
    |--------------------------------------------------------------------------
    | Caching
    |--------------------------------------------------------------------------
    */


    /**
     * Set Cache Folder
     *
     * @param string $dir
     *
     * @throws \BonsyRecmanException
     */
    public function setCacheFolder(string $dir): void {

        $dir = rtrim( $dir, '/' ) . '/';

        if( ! is_dir( $dir ) && ! mkdir( $dir, 0744, true ) && ! is_dir( $dir ) ) {
            throw new BonsyRecmanException( "Unable to find or create cache folder for " . self::PLUGIN_NAME );
        }

        $this->cache_folder = $dir;

    }




    /**
     * Get cache folder
     *
     * @return string
     * @throws \BonsyRecmanException
     */
    private function cacheFolder(): string {
        if( ! $this->cache_folder ) throw new BonsyRecmanException( "No cache folder is defined for " . self::PLUGIN_NAME . " please use method setCacheFolder()" );
        return $this->cache_folder;
    }




    /**
     * Get cache interval
     */
    private function cacheInterval(): int {
        $hour = (int)$this->date->format( 'G' );
        if( $hour >= 7 && $hour <= 17 ) return 15;
        if( $hour >= 18 && $hour <= 21 ) return 30;
        return 59;
    }




    /**
     * Get cache filename
     *
     * @return string
     * @throws \BonsyRecmanException
     */
    private function cacheFile(): string {
        $minutes = (int)$this->date->format( 'i' );
        $interval = floor( ( $minutes / $this->cacheInterval() ) + 1 );
        return $this->cacheFolder() . $this->date->format( 'Y-m-d_H' ) . "-$interval.json";
    }




    /**
     * Get Cached JSON Data
     *
     * @param string|null $file
     *
     * @return string|null
     * @throws \BonsyRecmanException
     */
    private function cacheContent(string $file = null): ?string {

        # Get the expected cache file
        $file = $file ?? $this->cacheFile();

        # Bail if no cache file is found
        if( ! is_file( $file ) || ! is_readable( $file ) ) return null;

        # Load Cache
        if( ini_get( 'allow_url_fopen' ) ) {

            if( function_exists( 'file_get_contents' ) ) {
                $data = @file_get_contents( $file );
                return $data ?: null;
            }

            if( function_exists( 'fopen' ) && function_exists( 'stream_get_contents' ) ) {
                $handle = fopen( $file, 'rb' );
                $data = @stream_get_contents( $handle );
                return $data ?: null;
            }

        }

        if( function_exists( 'curl_exec' ) ) {
            #$path = str_replace( WP_CONTENT_DIR, WP_CONTENT_URL, $path );
            $conn = curl_init( $file );
            curl_setopt( $conn, CURLOPT_SSL_VERIFYPEER, true );
            curl_setopt( $conn, CURLOPT_FRESH_CONNECT, true );
            curl_setopt( $conn, CURLOPT_RETURNTRANSFER, true );
            $data = curl_exec( $conn );
            curl_close( $conn );
            return $data ?: null;
        }

        return null;

    }




    /**
     * Get all cache folder file list
     *
     * @return array
     * @throws \BonsyRecmanException
     */
    private function cacheFolderFileList(): array {
        $list = [];
        $folder = $this->cacheFolder();
        if( $handle = opendir( $folder ) ) {
            while( false !== ( $file = readdir( $handle ) ) ) {
                if( strpos( $file, '.json' ) !== false ) {
                    $list[] = $folder . $file;
                }
            }
            closedir( $handle );
        }
        return $list;
    }




    /**
     * Delete all cache files
     *
     * @throws \BonsyRecmanException
     */
    public function cacheDelete(bool $force_reload = false, array $settings = []): void {
        foreach( $this->cacheFolderFileList() as $file ) {
            if( is_file( $file ) ) unlink( $file );
        }
        if( $force_reload ) $this->load( $settings, $force_reload );
    }




    /**
     * Delete the cache folder
     *
     * @noinspection PhpUnused
     * @throws \BonsyRecmanException
     */
    public function cacheDeleteFolder(): void {
        $this->deleteFolderWithFiles( $this->cacheFolder() );
    }




    /** Delete folder and all its files */
    public function deleteFolderWithFiles(string $dir): void {

        $dir = rtrim( $dir, '/' );

        if( function_exists( 'scandir' ) && $dir && is_dir( $dir ) ) {

            $items = scandir( $dir );

            foreach( $items as $item ) {

                if( $item === '.' || $item === '..' ) continue;

                $item = $dir . '/' . $item;

                if( is_file( $item ) ) {
                    unlink( $item );
                    continue;
                }

                if( is_dir( $item ) ) {
                    $this->deleteFolderWithFiles( $item );
                }

            }

            rmdir( $dir );

        }

    }




    /**
     * Get the latest cache file
     *
     * @return string|null
     * @throws \BonsyRecmanException
     */
    private function cacheLastContent(): ?string {
        $list = $this->cacheFolderFileList();
        rsort( $list );
        return $this->cacheContent( current( $list ) );
    }




    /**
     * Save Cache
     *
     * @throws \BonsyRecmanException
     */
    private function cacheSave($data): void {

        # Get the cache filename
        $file = $this->cacheFile();

        # Delete old cache
        $this->cacheDelete();

        # Save cache
        if( function_exists( 'file_put_contents' ) ) {
            file_put_contents( $file, $data );
        }

        # Return if the file now exists
        if( file_exists( $file ) ) return;

        # Else we will try to save using fopen
        $fp = fopen( $file, 'xb' );
        fwrite( $fp, $data );
        fclose( $fp );

    }




    /*
    |--------------------------------------------------------------------------
    | Fetch jobs from Bonsy
    |--------------------------------------------------------------------------
    */

    private function fetchJobs(array $settings = []): ?string {

        try {
            $result = ( $this->demo_mode ) ? $this->fetch( $settings, 'demo' ) : $this->fetch( array_merge( [ 'token' => $this->token() ], $settings ) );
            $this->cacheSave( $result );
        } catch ( Throwable $e ) {
            return null;
        }

        return $result;

    }




    /**
     * Custom Error Handler
     *
     * @param int $level
     * @param string $message
     * @param string $file
     * @param int $line
     *
     * @throws \ErrorException
     */
    public function handleError(int $level, string $message, string $file = '', int $line = 0): void {
        if( $level && error_reporting() ) {
            throw new ErrorException( $message, 0, $level, $file, $line );
        }
    }




    /**
     * Fetch API Call
     *
     * @param array $parameters
     * @param string $scope
     *
     * @return string|null
     * @throws \BonsyRecmanException
     */
    private function fetch(array $parameters = [], string $scope = ''): ?string {

        $parameters['plugin_version'] = self::PLUGIN_VERSION;

        $uri = self::BASE_URL;
        $uri .= ( $scope ) ? trim( $scope, '/' ) . '/' : '';
        $uri .= ( $parameters ) ? '?' . http_build_query( $parameters ) : '';

        $result = null;
        $error = null;

        if( function_exists( 'curl_exec' ) ) {

            # Init cURL
            $ch = curl_init();

            # The URL to fetch. This can also be set when initializing a session with curl_init().
            curl_setopt( $ch, CURLOPT_URL, $uri );

            # true to fail verbosely if the HTTP code returned is greater than or equal to 400. The default behavior is to return the page normally, ignoring the code.
            curl_setopt( $ch, CURLOPT_FAILONERROR, false );

            # True to include the header in the output.
            curl_setopt( $ch, CURLOPT_HEADER, 0 );

            # false to stop cURL from verifying the peer's certificate.
            # Alternate certificates to verify against can be specified with the CURLOPT_CAINFO option or a
            # certificate directory can be specified with the CURLOPT_CAPATH option.
            # curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );

            # true to return the transfer as a string of the return value of curl_exec() instead of outputting it directly.
            curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1 );

            $result = curl_exec( $ch );

            if( curl_errno( $ch ) ) {
                $error = curl_error( $ch );
            }

            curl_close( $ch );

        }

        if( empty( $result ) && ini_get( 'allow_url_fopen' ) ) {

            set_error_handler( [ $this, 'handleError' ], E_ALL );

            if( function_exists( 'file_get_contents' ) ) {

                try {
                    $result = file_get_contents( $uri, false, stream_context_create( [
                        'http' => [ 'ignore_errors' => true ],
                        'ssl'  => [
                            'verify_peer'      => false,
                            'verify_peer_name' => false,
                        ],
                    ] ) );
                } catch ( Throwable $e ) {
                    $error = $e->getMessage();
                }
            }


            if( empty( $result ) && function_exists( 'fopen' ) && function_exists( 'stream_get_contents' ) ) {
                try {
                    $handle = fopen( $uri, 'rb' );
                    $result = stream_get_contents( $handle );
                } catch ( Throwable $e ) {
                    $error = $e->getMessage();
                }

            }

            restore_error_handler();

        }

        if( empty( $result ) ) {
            $error = $error ?? '';
            throw new BonsyRecmanException( 'Unable to fetch data from Bonsy server for RecMan Plugin: ' . $error . '. Please contact Bonsy support.' );
        }


        try {
            $check = json_decode( $result, true, 512, JSON_THROW_ON_ERROR );
        } catch ( JsonException $e ) {
            throw new BonsyRecmanException( 'Unable to get a valid response from Bonsy Recman API server.' );
        }

        if( ! isset( $check['success'] ) ) {
            throw new BonsyRecmanException( 'No success field in the response from server' );
        }

        return $result;

    }






    /*
    |--------------------------------------------------------------------------
    | Settings & API Keys
    |--------------------------------------------------------------------------
    */


    /**
     * Register account - will return a license (token)
     *
     * @param string $recman_api_key
     *
     * @return string
     * @throws \BonsyRecmanException
     * @noinspection PhpUnused
     */
    public function register(string $recman_api_key): string {

        $result = $this->fetch( [
            'recman_access_token' => $recman_api_key
        ], 'register' );


        try {
            $result = json_decode( $result, false, 512, JSON_THROW_ON_ERROR );
        } catch ( JsonException $e ) {
            throw new BonsyRecmanException( 'Unable to convert Bonsy Recman API request. ' . $e->getMessage() );
        }

        if( isset( $result->token ) ) {
            if( empty( $this->token ) ) $this->setToken( $result->token );
            return (string)$result->token;
        }

        throw new BonsyRecmanException( $result->message ?? 'Unable to register account. Unknown error' );

    }




    /**
     * Update Recman Token - Will return true on success
     *
     * @param string $recman_api_key
     *
     * @return bool
     * @throws \BonsyRecmanException
     * @noinspection PhpUnused
     */
    public function updateRecmanApiKey(string $recman_api_key): bool {

        $result = $this->fetch( [
            'token'               => $this->token(),
            'recman_access_token' => $recman_api_key
        ], 'updateRecmanKey' );

        try {
            $result = json_decode( $result, false, 512, JSON_THROW_ON_ERROR );
        } catch ( JsonException $e ) {
            throw new BonsyRecmanException( 'Unable to convert Bonsy Recman API request. ' . $e->getMessage() );
        }

        if( isset( $result->success ) && $result->success === true ) {
            return true;
        }

        throw new BonsyRecmanException( $result->message ?? 'Unable to update Recman API Key in your account. Unknown error.' );

    }




    /**
     * @param array $settings
     *
     * @return bool
     * @throws \BonsyRecmanException
     * @noinspection PhpUnused
     */
    public function updateSettings(array $settings): bool {

        $settings = array_replace( [
            'token'  => $this->token(),
            'domain' => get_site_url()
        ], $settings );

        $result = $this->fetch( $settings, 'settings/save' );
        try {
            $result = json_decode( $result, false, 512, JSON_THROW_ON_ERROR );
        } catch ( JsonException $e ) {
            throw new BonsyRecmanException( 'Unable to convert Bonsy Recman API request. ' . $e->getMessage() );
        }

        if( isset( $result->success ) && $result->success === true ) {
            return true;
        }

        throw new BonsyRecmanException( $result->message ?? 'Unable to update settings in your account. Unknown error.' );

    }




    /**
     * Validate Recman API Key Settings
     *
     * @return bool
     * @throws \BonsyRecmanException
     * @noinspection PhpUnused
     */
    public function validateRecmanApiKey(): bool {

        $result = $this->fetch( [ 'token' => $this->token() ], 'validate' );
        try {
            $result = json_decode( $result, false, 512, JSON_THROW_ON_ERROR );
        } catch ( JsonException $e ) {
            throw new BonsyRecmanException( 'Unable to convert Bonsy Recman API request. ' . $e->getMessage() );
        }

        if( isset( $result->success ) && $result->success === true ) {
            return true;
        }

        throw new BonsyRecmanException( $result->message ?? 'Unable to validate API Recman Key. Unknown error.' );

    }




    /*
    |--------------------------------------------------------------------------
    | Helpers
    |--------------------------------------------------------------------------
    */

    /**
     * Get Required Token
     *
     * @return string
     * @throws \BonsyRecmanException
     */
    private function token(): string {
        if( ! $this->token ) {
            throw new BonsyRecmanException( 'Token must be set using the method setToken() in ' . self::PLUGIN_NAME );
        }
        return $this->token;
    }




    /**
     * Get job by ID
     *
     * @param int $id
     *
     * @return array|null
     */
    public function getJobById(int $id): ?array {
        foreach( $this->jobs as $job ) {
            if( isset( $job['jobPostId'] ) && (int)$job['jobPostId'] === $id ) return $job;
        }
        return null;
    }




    /**
     * Get ID of job by permalink
     *
     * @param string $permalink
     *
     * @return int|null
     */
    private function getJobIdByPermalink(string $permalink): ?int {
        return array_key_exists( $permalink, $this->permalinks ) ? (int)$this->permalinks[$permalink] : null;
    }




    public function setCurrentJobByPermalink(string $permalink): bool {
        $job = $this->getJobByPermalink( $permalink );
        if( ! $job ) return false;
        $this->loop_current[self::DEFAULT_LOOP_ID] = $job;
        return true;
    }




    /**
     * Get Job by permalink
     *
     * @param string $permalink
     *
     * @return array|null
     * @noinspection PhpUnused
     */
    public function getJobByPermalink(string $permalink): ?array {
        $id = $this->getJobIdByPermalink( $permalink );
        if( $id ) {
            return $this->getJobById( $id );
        }
        return null;
    }




    /**
     * Get the last external fetch date
     *
     * @return \DateTime
     * @noinspection PhpUnused
     * @throws \Exception
     */
    public function lastFetchDate(): DateTime {
        $date = $this->updated['date'] ?? 'now';
        $date = new DateTime( $date );
        $date->setTimezone( $this->timezone );
        return $date;
    }




    /**
     * Get the expiry date of Bonsy license
     *
     * @return \DateTime
     * @noinspection PhpUnused
     * @throws \Exception
     */
    public function licenseExpiryDate(): DateTime {
        $date = new DateTime( $this->license['expires'] ?? 'now' );
        $date->setTimezone( $this->timezone );
        return $date;
    }




    /**
     * Get license data
     *
     * @return array
     * @noinspection PhpUnused
     */
    public function getLicense(): array {
        return $this->license;
    }




    /**
     * Get stored settings
     *
     * @return array
     * @noinspection PhpUnused
     */
    public function getSettings(): array {
        return $this->settings;
    }




    /**
     * Get department list
     *
     * @return array
     */
    public function getDepartments(): array {
        return $this->departments;
    }




    /**
     * Get corporation list
     */
    public function getCorporations(): array {
        return $this->corporations;
    }



    /*
    |---------------------------------------------------------------------------
    | Loops
    |---------------------------------------------------------------------------
    */

    /** Define the loop ID */
    private function loopId(bool $is_object = false): ?string {
        return ( $is_object ) ? $this->current_object : self::DEFAULT_LOOP_ID;
    }




    /**
     * Check if we have a loop or define a new loop
     *
     * @param string|null $object
     * @param array|null $data
     *
     * @return bool
     */
    private function have_loop(string $object = null, array $data = null): bool {

        # Define new object
        $this->current_object = $object;
        $id = $this->loopId( (bool)$object );

        # If no loop is defined, we must define one
        if( ! isset( $this->loop[$id] ) ) {
            $this->loop[$id] = array_values( $data ?? $this->jobs_filtered );
        }

        # If loop has items, return true
        if( ! empty( $this->loop[$id] ?? [] ) ) return true;

        # If the requested loop is an object, the object is empty and can be removed.
        if( $object ) unset( $this->loop[$id] );

        return false;

    }




    /** Get the current loop */
    public function the_loop(bool $is_object = false) {

        $id = $this->loopId( $is_object );

        if( is_null( $id ) ) return null;

        # Reset the current
        $this->loop_current[$id] = null;

        # Shift the  next item to current
        if( ! empty( $this->loop[$id] ) ) {
            $this->loop_current[$id] = array_shift( $this->loop[$id] );
        }

        return $this->loop_current[$id];

    }




    /** Get value from current loop */
    public function get(string $field, int $job_id = null, bool $is_object = false) {

        $id = $this->loopId( $is_object );

        if( is_null( $id ) ) return null;

        if( $job_id && $job = $this->getJobById( $job_id ) ) {
            return $job[$field] ?? null;
        }

        return $this->loop_current[$id][$field] ?? null;

    }




    /**
     * Get JobPosts
     *
     * @param bool $filtered
     *
     * @return array
     */
    public function getJobs(bool $filtered = true): array {
        return ( $filtered ) ? $this->jobs_filtered : $this->jobs;
    }


    /*
    |--------------------------------------------------------------------------
    | Template
    |--------------------------------------------------------------------------
    */

    /**
     * Get the number of job posts
     *
     * @param bool $filtered
     *
     * @return int
     * @noinspection PhpUnused
     */
    public function countJobs(bool $filtered = true): int {
        return count( $this->getJobs( $filtered ) );
    }




    /**
     * Get total number of positions available
     *
     * @param bool $filtered
     *
     * @return int
     * @noinspection PhpUnused
     */
    public function countPosition(bool $filtered = true): int {
        $count = 0;
        foreach( $this->getJobs( $filtered ) as $job ) {
            if( isset( $job['numberOfPositions'] ) && is_numeric( $job['numberOfPositions'] ) ) {
                $count += (int)$job['numberOfPositions'];
            }
        }
        return $count;
    }




    /**
     * Get distinct values from a field
     *
     * @param string $field
     * @param bool $filtered
     *
     * @return array
     * @noinspection PhpUnused
     */
    public function distinct(string $field, bool $filtered = false): array {

        $list = [];

        foreach( $this->getJobs( $filtered ) as $jobs ) {

            $key = $value = $jobs[$field] ?? null;

            if( $field === 'department' ) {
                $key = $jobs['departmentId'] ?? null;
            }

            if( $key ) {
                $list[$key] = $value;
            }

        }

        return array_unique( $list );
    }




    /**
     * Check if filters is active for a given field and optionally a given value
     *
     * @param string $field
     * @param string|null $value
     *
     * @return bool
     * @noinspection PhpUnused
     */
    public function hasFilter(string $field, string $value = null): bool {

        $parameter = $this->filters[$field] ?? null;

        if( is_null( $parameter ) ) return false;
        if( is_null( $value ) ) return true;

        $value = str_replace( ',', '', $value );
        $value = strtolower( trim( $value ) );

        $parameter = strtolower( trim( $parameter ) );

        return strpos( $parameter, $value ) !== false;

    }




    /**
     * Check if there are any jobs to loop through
     *
     * @return bool
     * @noinspection PhpUnused
     */
    public function have_jobs(): bool {
        return $this->have_loop();
    }




    /**
     * Set the next job in loop
     *
     * @return mixed|null
     * @noinspection PhpUnused
     */
    public function the_job() {
        return $this->the_loop();
    }




    /**
     * Check if there are any object to loop through
     *
     * @param string $object
     *
     * @return bool
     * @noinspection PhpUnused
     */
    public function have_object(string $object): bool {

        $data = $this->get( $object );

        if( $data && is_array( $data ) ) {
            return $this->have_loop( $object, array_values( $data ) );
        }

        return false;

    }




    /**
     * Set the next object to loop
     *
     * @return mixed|null
     * @noinspection PhpUnused
     */
    public function the_object() {
        return $this->the_loop( true );
    }




    /**
     * Get data connected to the current object in loop
     *
     * @param string $field
     * @param int|null $id
     *
     * @return mixed|null
     * @noinspection PhpUnused
     */
    public function get_object(string $field, int $id = null) {
        return $this->get( $field, $id, true );
    }




    /**
     * Get URL of page including current filters
     * A helper to build filter URL for the current page
     * This will include current search queries and append these to the page url.
     * If the given key and value exists, it will remove this search
     *
     * @param string $key
     * @param string $value
     *
     * @return string
     * @noinspection PhpUnused
     */
    public function getFilterUrl(string $key, string $value): string {

        $search = $this->filters;

        # Create the parameter and include current value if exists
        $search[$key] = $search[$key] ?? '';

        # Make sure the given value doesn't contain comma
        $value = str_replace( ',', '', $value );

        # Remove value if filters already has the value or add value to URL
        if( strpos( $search[$key], $value ) !== false ) {
            $search[$key] = str_replace( $value, '', $search[$key] );
        } else {
            $search[$key] .= ",$value";
        }

        # Trim comma
        $search[$key] = str_replace( ',,', ',', $search[$key] );
        $search[$key] = trim( $search[$key], ',' );

        # Create the query
        $search = array_filter( $search, static function ($v) {
            return $v !== '';
        } );

        # Return page link with search query
        return ( $search ) ? $this->pageUrl . '?' . http_build_query( $search ) : $this->pageUrl;

    }


}