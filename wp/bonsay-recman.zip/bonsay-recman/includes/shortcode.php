<?php

add_action( 'wp_enqueue_scripts', static function () {
    wp_register_style( 'bonsy-shortcode', false );
    wp_enqueue_style( 'bonsy-shortcode' );
    $css = str_replace( [ "\r", "\n", "\t" ], '', get_option( 'bonsy_shortcode_custom_css', '' ) );
    $css = preg_replace('!\s+!', ' ', $css);
    wp_add_inline_style( 'bonsy-shortcode', $css );
} );


/**
 * RecMan JobPost Feed Shortcode
 */
add_shortcode( 'job_post_feed', static function ($params = [], $content = null, $tag = '') {

    // Bail early if RecMan WP Plugin isn't active
    if( ! function_exists( 'have_jobposts' ) || ! function_exists( 'get_jobpost' ) ) return $content;

    // Reset job post loop - important if the job post loop has been used earlier in the page
    reset_jobpost_loop();

    // No need to continue if no job posts.
    if( ! have_jobposts() ) return 'No job posts available';

    /** Register the CSS to style your shortcode. */ //wp_enqueue_style( 'recman-jobpost-shortcode', get_stylesheet_directory_uri() . '/recman_shortcode/recman.css' );

    // Load template or bail early if no template is found
    $template = get_option( 'bonsy_shortcode_html_template' );
    if( ! $template || ! is_string( $template ) ) return $content;

    // Normalize attribute keys, lowercase
    $params = is_array( $params ) ? array_change_key_case( (array)$params, CASE_LOWER ) : [];

    // Override default attributes with user attributes
    $options = shortcode_atts( [ 'count' => 10000000 ], $params, $tag );

    // Define the count
    $count = 0;

    $html = "";

    while( have_jobposts() ) {

        if( ++$count > (int)$options['count'] ) break;

        the_jobpost();

        $html .= preg_replace_callback( '/{{(.*?)}}/', static function ($matches) {
            return get_jobpost( trim( str_replace( [ '{{', '}}' ], '', $matches[0] ) ) );
        }, $template );

    }

    return "<div id='job-post-feed'>$html</div>";

} );