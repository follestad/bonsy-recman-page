<div class='bonsay-block'>
    <div class="title"><h3>Changelog</h3></div>
    <div class="inner changelog">

        <h4>Jan 27, 2023 - v2.4.0</h4>
        <ul>
            <li>Added build-in support for shortcode. You can use the shortcode <code>[job_post_feed]</code> to list job
                posts. This must be activated in the settings and a custom CSS and HTML must be added.
            </li>
            <li>Improved handling of filters</li>
            <li>Count for filtered list will adjust according to filtered list</li>
            <li>Filter now support department names</li>
            <li>Added changelog to settings</li>
            <li>Better blocking of search engines for filtered results in job posts as this could lead to crawlers goes
                into loop.
            </li>
        </ul>

        <h4>Des 29, 2022 - v2.3.0</h4>
        <ul>
            <li>Option to sort jobs by created, updated or startDate</li>
        </ul>

    </div>
</div>