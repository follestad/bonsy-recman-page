<?php if( ! defined( 'ABSPATH' ) ) exit; ?>

<div class='bonsay-block'>
    <div class="title"><h3>Register account</h3></div>
    <div class="inner">

        <p>
            Get started by adding your RecMan API Key.
            The key will be stored on the Bonsy server for security reasons, and a Bonsy license associated with
            your RecMan API key will be added to this WordPress Site automatically.
        </p>

        <div class="warning info">

            <p>
                If your API key is already associated with an account on Bonsy, it will automatically connect to
                this account. Otherwise, it will generate a new account with a 1-month free trial.
            </p>
            <p>
                Please contact Bonsy at kristoffer@bonsy.no to activate your subscription, for prices or for any details
                about this plugin.
            </p>

        </div>

        <!--suppress HtmlUnknownTarget -->
        <form method="post" action="options.php">
            <?php settings_fields( 'bonsy_license_section' ); ?>
            <label for="bonsy_license">Recman API Key
            </label>
            <input name='bonsy_license' id='bonsy_license' type='text' value=''/>
            <div class='buttons'>
                <?php submit_button( 'Activate' ); ?>
                <small><a href='https://app.recman.no/user/api.settings.php' target='_blank'><span
                                class='dashicons dashicons-external'></span> Generate a RecMan API key here</a></small>
            </div>
        </form>

    </div>
</div>