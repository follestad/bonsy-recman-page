<div class='bonsay-block'>
    <div class="title"><h3>Changelog</h3></div>
    <div class="inner changelog">

        <h4>Aug 2, 2023 - v2.5.4</h4>
        <ul>
            <li>
                <strong>Improved SEO data:</strong> oEmbed is disabled for single job posts as it is not possible for oEmbed to get content of job post. Site like LinkedIn will now ignore oEmbed and read the correct meta tags instead.
            </li>
        </ul>

        <h4>Jun 30, 2023 - v2.5.0</h4>
        <ul>
            <li>
                <strong>Implemented Shortcode Functionality for Job Post Fields:</strong> You can now extract specific
                job post fields with the newly added shortcode feature, for example, <code>[job_post_field
                    name="title"]</code>. This
                enhancement empowers you to craft individual job post pages with the help of shortcodes. This is
                particularly advantageous if you're leveraging theme builders like Elementor, Divi, etc.
            </li>
            <li>
                <strong>New Shortcode for Displaying Contact Persons:</strong> We've introduced a shortcode,
                <code>[job_post_contacts]</code>, to display contact persons in individual job posts. It uses a
                default HTML markup. We will add support for custom markup in the future.
            </li>
            <li><strong>Demo Mode improvements:</strong> We've expanded our admin page functionalities to include
                options for managing shortcodes, accessing the changelog, viewing cache, and deleting cache within the
                demo mode.
            </li>
        </ul>

        <h4>Feb 23, 2023 - v2.4.2</h4>
        <ul>
            <li>Added options for custom fields in shortcode</li>
            <li>Option to set custom "no job post available" text for shortcode using <code>no_job_post_message</code>
                attribute.
            </li>
        </ul>

        <h4>Jan 27, 2023 - v2.4.0</h4>
        <ul>
            <li>Added build-in support for shortcode. You can use the shortcode <code>[job_post_feed]</code> to list job
                posts. This must be activated in the settings and a custom CSS and HTML must be added.
            </li>
            <li>Improved handling of filters</li>
            <li>Count for filtered list will adjust according to filtered list</li>
            <li>Filter now support department names</li>
            <li>Added changelog to settings</li>
            <li>Better blocking of search engines for filtered results in job posts as this could lead to crawlers goes
                into loop.
            </li>
        </ul>

        <h4>Des 29, 2022 - v2.3.0</h4>
        <ul>
            <li>Option to sort jobs by created, updated or startDate</li>
        </ul>

    </div>
</div>