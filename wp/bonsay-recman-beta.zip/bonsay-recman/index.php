<?php // He who does not understand your silence will probably not understand your words.
